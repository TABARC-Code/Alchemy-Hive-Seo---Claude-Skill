# ALCHEMY-HIVE Skill Installation & Setup

Full SEO skill system. Policy-governed core, psychology-driven protocols, bidirectional feedback loops.

---

## What you're getting

23 operational files across seven layers:
- **Master router** — all requests flow through SKILL.md
- **Persistent memory** — memory.md is the single source of truth
- **Four page roles** — Scout, Follower, Memory, Outlier with full procedures
- **Seven alchemy protocols** — EA, HI, CS, TA, LPD, AW, AP
- **Intelligence layer** — waggle dance research, counterfactual test gate
- **Audit layer** — full site audit, feedback-loop propagation
- **Measurement** — five-dimension model covering visibility, friction, trust, adaptive gain, anti-fragility

**No placeholder scaffolding.** Every procedure is complete.

---

## Installation

### Option 1: Claude.ai skill platform

1. Drop the skill package in Claude's skill directory
2. Activate it in settings
3. Type `audit [domain]` or `scout [topic]` to start

### Option 2: Node.js CLI (local development)

```bash
cd alchemy-hive-skill
node skill-handler.js
```

Then type commands like:
- `audit example.com`
- `scout "demand signal topic"`
- `alchemy context about stuck page`

### Option 3: Direct integration

Import the skill handler in your Claude integration:

```javascript
const { handleRequest } = require('./skill-handler.js');

const response = await handleRequest('audit mysite.com', { sessionId: 'session-123' });
```

---

## Quick Start

### 1. Run a site audit

```
audit example.com
```

**Output:** page-role-register, colony-core checklist results, counterfactual content test outcomes, anti-waggle signals, pending review calendar.

### 2. Brief a scout page

```
scout "demand for left-field subtopic we haven't covered"
```

**Output:** scout brief template, memory log entry, 90-day review date set.

### 3. Check memory state

```
memory
```

**Output:** active experiments, page roles by site, pending reviews, protocol history.

### 4. Run a measurement snapshot

```
measure
```

**Output:** five-dimension results (visibility, cognitive friction, trust accumulation, adaptive gain, anti-fragility).

---

## How it works

### The core loop

1. **Entrypoint:** SKILL.md routes your request
2. **Execution:** Relevant skill file runs its procedure
3. **Bidirectional propagation:** Results write to memory.md and trigger downstream effects
4. **Feedback:** failures and wins feed back up the chain via feedback-loops.md

### Link contracts

Every skill declares what it calls and what calls it. When A transitions a page to B, both A's and B's records update. When an experiment wins, it propagates to similar pages automatically.

**This is not casual backlinking.** Every relationship is explicit and reciprocated.

### Memory persistence

`memory/memory.md` is where everything lives:
- All page role assignments
- All active experiments with hypotheses
- All review dates and outcomes
- All protocol applications
- Signal discoveries
- Graduation log

Nothing disappears. Retirements and failures are documented with named reasons so the system learns.

---

## Key files you'll interact with

| File | Purpose | When you use it |
|---|---|---|
| SKILL.md | Master router | Every session starts here |
| memory/memory.md | System state | Load at session start, write at end |
| audit/site-audit.md | Full site audit | New domain or 6-month health check |
| roles/scout-bee.md | Scout briefing | Testing a new demand pattern |
| roles/follower-bee.md | Follower optimization | Improving a proven-intent page |
| roles/outlier-bee.md | Outlier strategy | Non-logical experiment with hypothesis |
| alchemy/alchemy-router.md | Protocol selector | When stuck or trying a non-logical move |
| intelligence/waggle-dance.md | Demand research | Before briefing scouts |
| audit/feedback-loops.md | Role transitions & reviews | Every 90/120 days or when experiments complete |

---

## Understanding the page roles

**Scout:** Probes one unknown. Tests new query patterns, formats, hidden intents. 90-day review deadline. Graduates to Follower, escalates to Outlier, or retires with named reason.

**Follower:** Exploitation page for proven demand. Carries most authority and traffic. Refreshed when SERP drifts or every 6 months. Success tracked via Dimensions 1–2 measurement.

**Memory:** Legacy asset with link equity and entity ownership. Refreshed at 6-month audits. Can be consolidated into Follower, refreshed in place, or retired.

**Outlier:** Controlled deviation. Tests a non-logical assumption with a named alchemy protocol. 120-day review. Graduates to Follower (becomes a policy) or retires with protocol feedback.

---

## The seven alchemy protocols

| Protocol | What it solves | When to use |
|---|---|---|
| **Expectation Architecture** | Snippet promise doesn't match page reality | Users click but bounce immediately |
| **Hidden Intent** | Page answers literal query but ignores anxiety | Users are confused, overwhelmed, uncertain |
| **Costly Signal** | Page looks cheap or untrustworthy | Low domain authority or new site |
| **Trivia Amplifier** | Find small interventions with outsized effects | Button copy, opening sentence, first-word choice |
| **Logic-Proof Detector** | Page broken by three logical intervention rounds | Technical + content + authority all fixed, still fails |
| **Anti-Waggle-Dance** | Demand signals outside the keyword tools | Reddit anxiety patterns, Amazon review clusters |
| **Adaptive Preference** | Second-best position feels resentful | Free tier, low ranking, new brand |

---

## Understanding memory.md

It's not one file. It's a structured database in markdown:

- **Active Sessions** — log of every routing event
- **Sites.[domain]** — per-site page role register, scout log, follower log, memory asset log, etc.
- **Protocol History** — trivia amplifier results, logic-proof escalations, alchemy applications, waggle dance signals
- **Pending Reviews** — calendar of all time-bounded deadlines

Load memory at session start. Write after every major action. Read it to understand system state.

---

## Workflow example

**Day 1: New site audit**
```
audit example.com
→ SKILL.md routes to audit/site-audit.md
→ site-audit runs six phases
→ writes page-role-register, colony-core results, CCT outcomes to memory
→ identifies top 3 scout opportunities from waggle-dance signals
```

**Day 2: Brief first scout**
```
scout "specific demand signal from anti-waggle"
→ SKILL.md routes to roles/scout-bee.md
→ scout-bee briefs with hidden intent hypothesis
→ runs counterfactual-test gate (must pass)
→ runs colony-core checklist (must pass)
→ page goes live, 90-day review date logged
```

**Day 90: Scout review**
```
review scout-page-URL
→ SKILL.md detects 90-day deadline in memory
→ triggers feedback-loops.md §Scout 90-day review
→ checks success signals
→ graduates to Follower (if 2+ signals fired) or escalates/retires (named reason)
→ updates memory
```

---

## Common commands

```
# Core procedures
audit [domain] — full site audit
scout [topic] — scout brief
follower [URL] — follower optimisation
outlier [strategy] — outlier brief with protocol
memory — view system state
measure — measurement snapshot

# Intelligence
waggle [topic] — demand research
counterfactual [URL/idea] — publishing gate test

# Alchemy
alchemy [problem type] — protocol router
hidden-intent [query] — intent classification
trivia [page] — find trivial high-leverage interventions
logic-proof [URL] — stuck page escalation

# Audit
review [90-day/120-day] — trigger pending review
feedback-loop — check all pending reviews
```

---

## Troubleshooting

**"Page failed colony-core checklist"**  
Don't publish. C1–C10 are non-negotiable. Fix the fail first.

**"Scout didn't index"**  
Check C1 (reachability). Could be robots.txt, noindex, or crawl issue.

**"Follower not moving despite fresh content"**  
Run logic-proof-detector. Three logical intervention rounds, then switch to non-logical (EA, HI, AP).

**"Memory.md got too large"**  
It's supposed to. Don't delete entries. Archive old years in a separate file, keep current year in memory.

**"Two scouts testing the same thing"**  
Check memory §Sites.[domain].Scout Log before briefing. Avoid duplication.

---

## What makes this different

- **Bidirectional contracts** — not just "A calls B"; A and B both acknowledge the relationship
- **Persistent failure documentation** — retirements name their failure reason, feeding back to protocols
- **Measurement across five dimensions** — not just rankings and traffic
- **Anti-fragility tracking** — does the site *benefit* from algorithm updates or does it break?
- **Alchemy layer** — non-logical interventions backed by psychology, not just SEO orthodoxy

---

## Next steps

1. Copy all files to your Claude environment
2. Load README.md for full documentation overview
3. Start with `audit [your-domain]` to establish baseline
4. Review page-role-register to understand your current site state
5. Check memory.md pending-reviews calendar regularly
6. Brief scouts from anti-waggle signals
7. Apply alchemy protocols to stuck pages

The system improves as you use it — wins get documented, losses feed back to protocol files, the framework learns.

Good luck. This is real infrastructure, not a template.
