---
id: scout-bee
version: "1.0"
layer: role

links:
  calls:
    - id: colony-core
      reason: "validates every scout page against C1–C10 before marking live"
      contract: "colony-core §Checklist receives scout URL from §Pre-live validation"
    - id: counterfactual-test
      reason: "gates scout publishing — scouts must pass CCT"
      contract: "counterfactual-test §Entrypoint receives scout topic from §Publishing gate"
    - id: memory
      reason: "logs every scout deployment with hypothesis and review date"
      contract: "memory §Sites.[domain].Scout Log receives entry on every deployment"
    - id: feedback-loops
      reason: "triggers graduation or retirement at 90-day review"
      contract: "feedback-loops §Scout 90-day review receives scout URL from §Review trigger"

  called_by:
    - id: SKILL
      reason: "routes scout briefing requests here"
      contract: "§Entrypoint receives routing from SKILL.md classification"
    - id: waggle-dance
      reason: "passes discovered signals as scout brief inputs"
      contract: "§Brief inputs receives signal report from waggle-dance §Signal output"
    - id: anti-waggle-dance
      reason: "passes non-tool demand signals as scout brief inputs"
      contract: "§Brief inputs receives non-tool signals from anti-waggle-dance §Output"
    - id: feedback-loops
      reason: "triggers graduate-to-follower flow when scout meets criteria"
      contract: "§Graduation procedure receives signal from feedback-loops §Scout graduation"
    - id: site-audit
      reason: "scout role is assigned to speculative/experimental pages during audit"
      contract: "§Entrypoint receives unclassified experimental pages from site-audit §Role assignment"

  chain_down:
    - id: colony-core
      relationship: "scout brief feeds colony-core checklist before live"
    - id: counterfactual-test
      relationship: "scout brief feeds CCT gate before live"
    - id: memory
      relationship: "scout deployment logs to memory"
    - id: follower-bee
      relationship: "scout graduates to follower — brief passes downstream"
  chain_up:
    - id: SKILL
      relationship: "receives routing from master"
    - id: waggle-dance
      relationship: "receives signal input"
    - id: anti-waggle-dance
      relationship: "receives non-tool signal input"

  lateral:
    - id: outlier-bee
      relationship: "scout patterns can inform outlier agenda; outlier findings can reframe scout hypotheses"
    - id: measurement-architecture
      relationship: "scout success metrics are defined in measurement-architecture §Dimension 4 Adaptive Gain"
    - id: memory
      relationship: "reads historical scout log at session start; writes new entries at session end"
---

# Scout Bee — Discovery Page Role

Scouts are probes. They test one unknown before the system commits. They do not carry internal authority, they do not chase proven volume, and they are not the colony's production pages. They discover things the follower layer hasn't seen yet.

---

## Entrypoint

Receives from `SKILL.md`, `waggle-dance.md`, or `anti-waggle-dance.md`:
- A topic, query pattern, or unknown to test
- (Optional) A signal source type (Reddit anxiety, SERP format gap, PAA cluster, anti-waggle discovery)
- (Optional) A hidden intent hypothesis

Before doing anything: check `memory/memory.md §Sites.[domain].Scout Log` to confirm no existing scout is already testing the same unknown. If there is, reference it rather than duplicating.

---

## What scouts test

A scout page tests exactly one of the following categories. State the category explicitly in the brief.

| Category | What it probes | Example unknown |
|---|---|---|
| **Query pattern** | A new way users are phrasing a known need | "how do I stop my X from doing Y" vs. "X not working" |
| **Subtopic** | A narrower slice of an established topic not yet covered | "Zigbee vs Thread for rented flats" in a home automation site |
| **SERP format** | Whether a specific format occupies a gap in the results | Does the SERP for this query have any featured snippets? Any How-To results? |
| **Hidden intent** | Whether addressing the anxiety behind a query performs better than addressing the literal query | Anxiety: "fear of making the wrong choice"; query: "best smart lights" |
| **Format type** | Whether a tool, calculator, decision tree, or framework outperforms an article in this space | — |
| **Anti-waggle signal** | A demand discovered outside keyword tools that may not yet have measurable volume | Language pattern from a Reddit thread; question cluster from competitor Q&A |
| **AI extractability** | Whether a page written for extraction rather than click-through generates AI Overview citations | — |

---

## Brief inputs

The scout brief requires:

1. **Working title** — not optimised, just descriptive
2. **Unknown being tested** — one sentence, specific, falsifiable
3. **Hidden intent hypothesis** — what anxiety or emotional state is the target user in? (See `alchemy/hidden-intent.md` for taxonomy)
4. **Signal source** — where did the demand evidence come from? (keyword tool / Reddit / Amazon / PAA / SERP volatility / other)
5. **Format** — article / tool / framework / decision tree / FAQ cluster / glossary entry / other
6. **Counterfactual check** — would the information landscape be different without this page? Confirm before briefing (see `intelligence/counterfactual-test.md`)
7. **Success signals** — what would constitute validation? Pick two from the scout success metrics list below

---

## Scout brief template

```
SCOUT BRIEF
Site: [domain]
Date: [DATE]
Briefed by: [skill that triggered this brief — waggle-dance / anti-waggle / SKILL.md]

Working title: [descriptive, not optimised]
Unknown tested: [one sentence — "We don't know whether users searching for X are actually anxious about Y"]
Hidden intent hypothesis: [anxiety / confusion / doubt / comparison fatigue / trust anxiety / budget concern]
Signal source: [keyword tool / Reddit / Amazon reviews / PAA cluster / SERP volatility / YouTube autocomplete / support thread / other]
Format: [article / tool / framework / decision tree / FAQ / glossary / other]
Target SERP format: [standard blue link / featured snippet / How-To / FAQ / AI Overview citation / People Also Ask]

Counterfactual test status: [PASSED / not yet run — must pass before live]

Success signals (pick two):
☐ Indexed within 14 days
☐ Any organic impression within 60 days
☐ CTR relative to impressions at 90 days exceeds site average
☐ Cited or extracted in an AI Overview
☐ Backlink from a domain not in the site's current profile
☐ SERP format occupied that site had not previously held
☐ Query pattern confirmed as distinct from existing Followers

90-day review date: [DATE + 90 days]
Memory log entry: [Confirm written to memory §Sites.[domain].Scout Log]
```

---

## Pre-live validation

Before a scout page is published:

1. Run `core/colony-core.md §Checklist` — all C1–C10 must pass
2. Run `intelligence/counterfactual-test.md` — all four questions must pass
3. Confirm the brief is logged in `memory/memory.md §Sites.[domain].Scout Log`
4. Confirm the 90-day review date is logged in `memory/memory.md §Pending Reviews`

If any of these fail, the page is not published. Fix the failure first.

---

## 90-day review procedure

At 90 days from deployment, `feedback-loops.md` triggers the review. Check:

1. **Was it indexed?** (Should happen within 14 days. If not indexed at 90 days: technical problem — run C1–C3 from colony-core.)
2. **Did it receive any organic impressions?** (Check Google Search Console for the exact URL.)
3. **What SERP position did it reach?** (Average position in GSC.)
4. **Did any success signals fire?** (Check the two signals selected in the brief.)
5. **Did the hidden intent hypothesis get confirmed or disconfirmed?** (Are engagement signals aligned with what you'd expect from a page addressing the stated anxiety?)

---

## Graduation criteria

A scout graduates to Follower when **two or more** of:

- Average position under 30 for the primary query
- Any organic clicks received
- One of the two named success signals fired
- A competitor has published a similar page (confirming the unknown is a real demand)
- The topic appears in PAA results for a related query

When graduating: brief `roles/follower-bee.md §Entrypoint` with the validated data. Write the graduation to `memory/memory.md §Protocol History.Graduation Log`.

---

## Retirement criteria

A scout is retired when **all** of:

- 90 days elapsed with zero organic impressions
- Not indexed (or indexed but no position in GSC)
- No success signals fired
- No competing pages have appeared in the SERP for the query pattern

When retiring: name the failure reason (from the list below) and log it in `memory/memory.md §Sites.[domain].Scout Log`. Do not delete the page silently. Mark it `noindex` and document why.

**Named failure reasons:**
- `intent-mismatch` — the page didn't match what the query population actually wanted
- `crawl-failure` — technical problem prevented indexing
- `commodity-content` — the page added nothing beyond what existed
- `no-demand` — the query pattern does not have sufficient search population
- `format-mismatch` — the SERP for this query expects a different format than what was published
- `hidden-intent-wrong` — the anxiety hypothesis was incorrect; users wanted factual information, not anxiety resolution

---

## Scout-to-Outlier escalation

If a scout consistently gets impressions but no clicks, and changing the snippet format doesn't help, the page may be better suited as an Outlier with a zero-click-first design strategy. Escalate to `roles/outlier-bee.md` with the GSC data.

---

## Link contracts

- `core/colony-core.md §Checklist` — receives scout URL from §Pre-live validation (this file calls colony-core)
- `intelligence/counterfactual-test.md §Entrypoint` — receives scout topic from §Publishing gate (this file calls CCT)
- `memory/memory.md §Sites.[domain].Scout Log` — receives new entry on every deployment (this file writes to memory)
- `memory/memory.md §Pending Reviews` — receives 90-day review date on every deployment (this file writes to memory)
- `audit/feedback-loops.md §Scout 90-day review` — receives scout URL from this file's §Review trigger (this file calls feedback-loops)
- `roles/follower-bee.md §Entrypoint` — receives validated scout data when graduating (this file chains to follower-bee)
- `intelligence/waggle-dance.md §Signal output` — supplies signal input to §Brief inputs in this file (waggle-dance calls this file)
- `alchemy/anti-waggle-dance.md §Output` — supplies non-tool signal input to §Brief inputs in this file (anti-waggle calls this file)
- `roles/outlier-bee.md` — lateral: scout escalations feed outlier agenda; outlier discoveries can reset scout hypotheses
