---
id: outlier-bee
version: "1.0"
layer: role

links:
  calls:
    - id: alchemy-router
      reason: "selects the alchemy protocol appropriate to the outlier hypothesis"
      contract: "alchemy-router §Entrypoint receives outlier context from §Protocol selection"
    - id: colony-core
      reason: "validates outlier pages against C1–C10 — technical compliance mandatory"
      contract: "colony-core §Checklist receives outlier URL from §Pre-live validation"
    - id: counterfactual-test
      reason: "gates outlier publishing — outliers must pass CCT despite their unconventional nature"
      contract: "counterfactual-test §Entrypoint receives outlier topic from §Publishing gate"
    - id: memory
      reason: "logs outlier hypothesis, protocol used, and 120-day review date"
      contract: "memory §Sites.[domain].Outlier Log receives entry on every deployment"
    - id: feedback-loops
      reason: "triggers graduation or retirement at 120-day review"
      contract: "feedback-loops §Outlier 120-day review receives outlier URL"

  called_by:
    - id: SKILL
      reason: "routes outlier briefing requests here"
      contract: "§Entrypoint receives routing from SKILL.md"
    - id: alchemy-router
      reason: "passes selected protocol back to outlier brief after selection"
      contract: "§Brief construction receives selected protocol from alchemy-router §Protocol output"
    - id: site-audit
      reason: "pages testing radical formats or hidden intent framings are assigned Outlier role"
      contract: "§Entrypoint receives experimental page assignments from site-audit §Role assignment"
    - id: scout-bee
      reason: "scouts that consistently get impressions but no clicks may escalate to outlier"
      contract: "§Entrypoint receives escalation data from scout-bee §Scout-to-Outlier escalation"
    - id: feedback-loops
      reason: "triggers 120-day review"
      contract: "§120-day review procedure receives review signal from feedback-loops"

  chain_down:
    - id: alchemy-router
      relationship: "outlier brief triggers protocol selection"
    - id: colony-core
      relationship: "outlier feeds colony-core checklist before live"
    - id: counterfactual-test
      relationship: "outlier feeds CCT gate before live"
    - id: memory
      relationship: "outlier hypothesis logs to memory"
    - id: follower-bee
      relationship: "validated outliers graduate to follower"
  chain_up:
    - id: SKILL
      relationship: "receives routing from master"
    - id: scout-bee
      relationship: "receives escalations from scouts with impression-but-no-click pattern"
    - id: alchemy-router
      relationship: "receives selected protocol from alchemy-router"

  lateral:
    - id: scout-bee
      relationship: "outlier findings can reset scout hypotheses; scout patterns can seed outlier agenda"
    - id: measurement-architecture
      relationship: "outlier success tracked via Dimension 4 Adaptive Gain and Dimension 1 brand recall"
    - id: anti-waggle-dance
      relationship: "anti-waggle signals frequently seed outlier hypotheses"
---

# Outlier Bee — Controlled Deviation Role

Outliers are the system's adaptive edge. Not random experiments. Not "weird for weird's sake." Controlled deviation with a named hypothesis, a selected alchemy protocol, a defined test window, and explicit success and failure criteria. The deviation is in strategy, not in technical compliance.

Outlier pages do things the rest of the SERP is too rational to do.

---

## Entrypoint

Receives from `SKILL.md`, `alchemy-router.md`, `scout-bee.md §Escalation`, or `site-audit.md §Role assignment`:
- Topic or page URL
- Hypothesis (what non-logical assumption is being tested?)
- Source signal (what motivated this outlier? Anti-waggle discovery, scout impression-no-click pattern, alchemy protocol trigger, explicit user request)
- Any existing performance data (if escalated from Scout)

Before proceeding: read `memory/memory.md §Sites.[domain].Outlier Log` to confirm no duplicate hypothesis is already being tested.

---

## What outlier pages do

An outlier page does at least one of the following. State which in the brief.

| Strategy | What it tests | Typical alchemy protocol |
|---|---|---|
| **Hidden intent framing** | Addresses the anxiety behind the query rather than the literal keyword | Hidden Intent (HI) |
| **Tool or framework format** | A calculator, decision tree, or original framework where the SERP is dominated by articles | Counterfactual Content / format inversion |
| **Zero-click first design** | Written for AI extraction or featured snippet capture rather than conventional click-through | Expectation Architecture (EA) + costly signal |
| **Adaptive preference reframe** | Reframes a second-best position (low-ranked, brand-new, free tier) as a chosen experience | Adaptive Preference Formation (AP) |
| **Costly signal saturation** | Deploys unusually high investment signals in a space where competitors are thin | Costly Signal (CS) |
| **Anti-waggle content** | Targets a demand pattern found outside keyword tools with no measurable search volume yet | Anti-Waggle-Dance (AW) |
| **Logic-proof response** | Tries a non-logical intervention on a persistent underperformer | Logic-Proof Detector (LPD) |
| **Trivia amplifier test** | Tests a small framing or structural change with disproportionate expected effect | Trivia Amplifier (TA) |

---

## Protocol selection

Call `alchemy/alchemy-router.md §Entrypoint` with:
- The outlier strategy type (from the table above)
- The topic and any existing performance data
- The source signal

Alchemy-router returns a selected protocol. That protocol governs the outlier's content design. Embed the protocol instructions in the brief.

---

## Outlier brief construction

```
OUTLIER BRIEF
Site: [domain]
Date: [DATE]
Source signal: [SKILL routing / scout escalation / anti-waggle discovery / audit assignment / explicit request]

Topic: [one sentence]
Strategy type: [from the table above]
Alchemy protocol applied: [EA / HI / CS / TA / LPD / AW / AP]
Protocol instructions: [copy the specific operating rules from the selected protocol file]

Hypothesis: [one sentence, falsifiable — "We believe that [intervention] will produce [outcome] because [reasoning based on the selected alchemy protocol]"]

Hidden intent (if applicable): [what anxiety or emotional state is the target user in?]
Format: [tool / framework / decision tree / FAQ cluster / article-with-unusual-structure / interactive / other]

Why is this non-obvious? [what would a rational SEO practitioner NOT do here, and why?]
Why does the non-obvious move have psychological or ecological logic? [one paragraph]

Counterfactual test status: [PASSED / not yet run — must pass before live]

Success signals — pick two, appropriate to the strategy:
For zero-click/AI extraction:
  ☐ Cited in an AI Overview for the primary query
  ☐ Featured snippet captured
  ☐ Brand search volume increases in the 120-day window
For hidden intent / format outlier:
  ☐ Engagement signal (scroll depth > 60%, time on page > 2x site average)
  ☐ Backlink from unexpected domain type (not a direct competitor)
  ☐ Conversion rate from organic landing exceeds Follower average for similar queries
For anti-waggle / no-volume outlier:
  ☐ Any organic impressions within 60 days
  ☐ Query pattern appears in PAA or autocomplete within 120 days
  ☐ Competitor publishes a similar page (confirming the unknown is real demand)

Failure signals — pre-commit to what failure looks like:
  [complete this before publishing — what would constitute a clear disconfirmation of the hypothesis?]

120-day review date: [DATE + 120 days]
Memory log entry: [Confirm written to memory §Sites.[domain].Outlier Log]
```

---

## Pre-live validation

Before an outlier page is published:

1. Run `core/colony-core.md §Checklist` — all C1–C10 must pass. The deviation is in strategy; technical compliance is not negotiable.
2. Run `intelligence/counterfactual-test.md` — outliers must also pass the CCT. If an outlier page adds nothing, it is just an unusual page that adds nothing.
3. Confirm the brief (especially the hypothesis and failure signals) is logged in `memory/memory.md §Sites.[domain].Outlier Log`
4. Confirm the 120-day review date is logged in `memory/memory.md §Pending Reviews`

---

## 120-day review procedure

Triggered by `feedback-loops.md §Outlier 120-day review`.

1. Retrieve the brief from memory — specifically the hypothesis and the named success/failure signals
2. Check each success signal: fired or not?
3. Check each failure signal: triggered or not?
4. **Hypothesis assessment:** was the non-logical assumption confirmed, disconfirmed, or ambiguous?

**Decision matrix:**

| Success signals | Failure signals | Hypothesis | Decision |
|---|---|---|---|
| ≥1 fired | Not triggered | Confirmed or ambiguous | Graduate to Follower |
| ≥1 fired | Not triggered | Disconfirmed | Graduate but document the surprise — update the alchemy protocol with the unexpected finding |
| 0 fired | Triggered | Disconfirmed | Retire — document failure reason in memory |
| 0 fired | Not triggered | Ambiguous | Extend by 60 days if there is a plausible explanation for the delay; else Retire |

---

## Graduation to Follower

When graduating: brief `roles/follower-bee.md §Entrypoint` with:
- The outlier URL
- The validated hypothesis (what actually worked)
- The alchemy protocol applied (so the Follower refresh retains the non-logical framing that made it work)
- All performance data

Write graduation to `memory/memory.md §Protocol History.Graduation Log`.

---

## Retirement procedure

When retiring: do not silently delete. Noindex the page and write to `memory/memory.md §Sites.[domain].Outlier Log`:
- URL
- Alchemy protocol applied
- Hypothesis stated
- Failure reason (from named list):
  - `protocol-wrong` — the alchemy protocol selected was inappropriate for this context
  - `hypothesis-wrong` — the non-logical assumption was simply incorrect
  - `no-demand` — the query pattern had insufficient search population even for an outlier
  - `format-mismatch` — the format was too unusual for this audience
  - `technical-failure` — indexing or crawl problem prevented the test from running
  - `anxiety-wrong` — the hidden intent classification was incorrect

Failure documentation feeds back into the alchemy protocol files as negative feedback. If an outlier fails with `protocol-wrong`, add a note to the relevant alchemy protocol file describing the context where it failed.

---

## Outlier-to-Scout pipeline

If an outlier tests a format or framing that shows partial signals (impressions but no clicks, or engagement but no ranking), it may generate a scout brief for an adjacent query cluster. The outlier becomes the authority source for that scout.

When creating a scout from an outlier: brief `roles/scout-bee.md §Entrypoint` with the outlier URL as the upstream authority source.

---

## Link contracts

- `alchemy/alchemy-router.md §Entrypoint` — receives outlier context from §Protocol selection (this file calls alchemy-router)
- `alchemy/alchemy-router.md §Protocol output` — supplies selected protocol back to §Brief construction (alchemy-router calls back to this file)
- `core/colony-core.md §Checklist` — receives outlier URL from §Pre-live validation (this file calls colony-core)
- `intelligence/counterfactual-test.md §Entrypoint` — receives outlier topic from §Publishing gate (this file calls CCT)
- `memory/memory.md §Sites.[domain].Outlier Log` — receives entry on every deployment and retirement (this file writes to memory)
- `memory/memory.md §Pending Reviews` — receives 120-day review date on every deployment (this file writes to memory)
- `audit/feedback-loops.md §Outlier 120-day review` — receives outlier URL from §120-day review procedure (this file calls feedback-loops)
- `roles/follower-bee.md §Entrypoint` — receives graduation briefing from §Graduation to Follower (this file chains to follower-bee)
- `roles/scout-bee.md §Entrypoint` — receives pipeline brief from §Outlier-to-Scout pipeline (this file calls scout-bee)
- `roles/scout-bee.md §Scout-to-Outlier escalation` — supplies escalation data to §Entrypoint (scout-bee calls this file)
- `alchemy/[protocol].md` — receives negative feedback from §Retirement procedure on protocol-wrong failures (this file calls back to protocol files)
