---
id: memory-bee
version: "1.0"
layer: role

links:
  calls:
    - id: colony-core
      reason: "validates memory assets at each 6-month audit against C1–C10"
      contract: "colony-core §Checklist receives memory asset URL from §Audit procedure"
    - id: costly-signal
      reason: "refreshes trust signals on memory assets during each audit cycle"
      contract: "costly-signal §Audit receives memory asset URL from §Signal refresh"
    - id: memory
      reason: "logs all audit outcomes and refresh decisions"
      contract: "memory §Sites.[domain].Memory Asset Log receives audit outcome"

  called_by:
    - id: SKILL
      reason: "routes memory asset management requests here"
      contract: "§Entrypoint receives routing from SKILL.md"
    - id: site-audit
      reason: "legacy pages with link equity or entity ownership are assigned Memory role"
      contract: "§Entrypoint receives legacy page assignments from site-audit §Role assignment"
    - id: follower-bee
      reason: "demoted followers are passed here with demotion reason and link equity status"
      contract: "§Entrypoint receives demotion briefing from follower-bee §Follower demotion"
    - id: feedback-loops
      reason: "triggers 6-month audit review"
      contract: "§Audit procedure receives review signal from feedback-loops §Memory audit trigger"

  chain_down:
    - id: colony-core
      relationship: "memory asset feeds colony-core at each 6-month audit"
    - id: costly-signal
      relationship: "memory asset feeds costly-signal audit for trust signal refresh"
    - id: memory
      relationship: "audit outcomes log to memory"
  chain_up:
    - id: site-audit
      relationship: "receives legacy page assignments"
    - id: follower-bee
      relationship: "receives demoted followers"

  lateral:
    - id: follower-bee
      relationship: "memory assets that recover signal strength can be reclassified as followers"
    - id: scout-bee
      relationship: "memory assets with established entity ownership can seed new scout briefs in adjacent subtopics"
---

# Memory Bee — Legacy Asset Role

Memory assets are not dead pages. They are the colony's accumulated trust — older pages with link equity, entity associations, and established ranking history. They should not be abandoned because they are old. They should be maintained because the trust they hold is expensive to rebuild from scratch.

---

## Entrypoint

Receives from `SKILL.md`, `site-audit.md §Role assignment`, or `follower-bee.md §Follower demotion`:
- Page URL
- Reason for Memory role assignment (legacy equity / entity ownership / established ranking / follower demotion)
- Current link equity status (inbound backlinks, internal links received)
- Current ranking data if available

Before proceeding: read `memory/memory.md §Sites.[domain].Memory Asset Log` for existing history on this page.

---

## Memory asset audit procedure

Run every 6 months. Triggered by `feedback-loops.md §Memory audit trigger`.

### Step 1 — Decay diagnosis

Check the page for each of the following decay indicators:

| Decay type | Check | Threshold for action |
|---|---|---|
| Outdated claims | Any statement referencing a year, version, or regulation that may have changed | Flag any claim over 18 months old |
| Broken examples | Any linked-to third-party resource returning non-200 | Any broken example |
| Stale statistics | Any numeric claim (percentage, study result, market size) | Flag any statistic over 2 years old |
| Dead external links | Check every outbound link | Any returning non-200 |
| SERP drift | Has the intent for the primary query changed since the page was written? | Compare current top-5 SERP to the page's angle |
| Competitor encroachment | Have stronger pages appeared in the SERP for this page's primary query? | Any top-3 result that clearly outperforms this page |
| Format obsolescence | Has the SERP shifted to a format this page no longer supports? | Dominant format now different from this page's format |

### Step 2 — Refresh vs. consolidate vs. retire decision

Based on the decay diagnosis:

**Refresh in place** when:
- Inbound link equity is substantial (3+ referring domains, or 10+ internal links from high-value pages)
- The entity ownership is intact (Google associates this URL with the topic)
- The decay is repairable without a fundamental rebuild
- Action: update outdated claims, fix broken links, add fresher statistics, strengthen trust signals

**Consolidate** when:
- A stronger, newer Follower page now covers the same topic
- The memory asset's content would strengthen the Follower if merged
- The inbound link equity can be transferred via 301 redirect
- Action: merge unique content into the Follower, 301-redirect the memory asset URL to the Follower, confirm the redirect passes link equity

**Retire** when:
- No inbound link equity (no referring domains, no significant internal links)
- The page has had zero organic traffic for 12+ months
- The topic is genuinely obsolete (product discontinued, regulation no longer in force)
- Action: noindex and log; do not delete (maintaining the URL prevents 404s on any obscure inbound links)

### Step 3 — Link equity preservation

If refreshing or consolidating:

1. Identify all pages linking TO this memory asset (internal and external)
2. For internal links: confirm they use descriptive anchor text and still make sense given any content refresh
3. For external links: note the referring domains — these are the equity that justifies this page's existence
4. If consolidating: confirm the 301 redirect is in place and the destination Follower page is strong enough to receive the equity

### Step 4 — Entity ownership check

Does Google still associate this URL with the entity it was written to own? Check:
- Does the page appear in knowledge panel sources?
- Does the page rank for branded entity queries (e.g., "[topic] + [site name]")?
- Is the page cited in any AI Overviews for the entity's primary query?

If entity ownership is weakening: strengthen by adding structured data, improving E-E-A-T signals, and re-publishing with a dated update notice.

### Step 5 — Trust signal refresh

Call `alchemy/costly-signal.md §Audit` with the page URL. Minimum for memory assets: two trust signals. Add the cheapest available signal that is currently missing.

### Step 6 — Colony Core validation

Call `core/colony-core.md §Checklist`. All C1–C10 must pass after refresh. Pay particular attention to:
- C2 (canonical — memory assets sometimes develop canonical conflicts with newer Follower pages)
- C8 (information gain — does the page still add to the information set after competitors have improved?)
- C9 (trust signals — update any stale authorship or citation information)

### Step 7 — Log to memory

Write audit outcome to `memory/memory.md §Sites.[domain].Memory Asset Log`:
- URL
- Date of audit
- Refresh type (in-place / consolidated / retired)
- Link equity status (referring domain count, internal link count)
- Entity ownership status
- Next audit date (6 months from now)

---

## Memory asset seeding scouts

Memory assets with strong entity ownership can seed adjacent scout briefs. If a memory asset ranks for [Entity X] and the Anti-Waggle-Dance scan surfaces demand for [Entity X + adjacent subtopic], brief a Scout page with the memory asset as its internal authority source.

When seeding a Scout this way: brief `roles/scout-bee.md §Entrypoint` with the memory asset URL as the upstream authority source. The Scout brief must include an internal link FROM the Scout TO the memory asset, and a reciprocal internal link FROM the memory asset TO the Scout (once the Scout is live).

---

## Recovery to Follower

A memory asset is reclassified as Follower when:
- A refresh cycle produces a measurable increase in organic impressions or clicks
- The page reaches average position under 30 for its primary query after refresh
- The topic regains search volume (e.g., seasonal, regulatory change, product re-launch)

When recovering: brief `roles/follower-bee.md §Entrypoint` with the recovery data.

---

## Link contracts

- `core/colony-core.md §Checklist` — receives memory asset URL from §Audit procedure (this file calls colony-core)
- `alchemy/costly-signal.md §Audit` — receives memory asset URL from §Signal refresh (this file calls costly-signal)
- `memory/memory.md §Sites.[domain].Memory Asset Log` — receives audit outcome (this file writes to memory)
- `roles/follower-bee.md §Follower demotion` — supplies demotion briefing to §Entrypoint (follower-bee calls this file)
- `roles/follower-bee.md §Entrypoint` — receives recovery briefing from §Recovery to Follower (this file calls follower-bee on recovery)
- `roles/scout-bee.md §Entrypoint` — receives seed brief from §Memory asset seeding scouts (this file calls scout-bee when seeding)
- `audit/site-audit.md §Role assignment` — supplies legacy page assignments to §Entrypoint (site-audit calls this file)
- `audit/feedback-loops.md §Memory audit trigger` — supplies 6-month review signal to §Audit procedure (feedback-loops calls this file)
