---
id: follower-bee
version: "1.0"
layer: role

links:
  calls:
    - id: colony-core
      reason: "validates follower at each refresh cycle against C1–C10"
      contract: "colony-core §Checklist receives follower URL from §Refresh cycle"
    - id: counterfactual-test
      reason: "re-runs publishing gate at each refresh cycle"
      contract: "counterfactual-test §Entrypoint receives follower URL from §Refresh cycle"
    - id: expectation-architecture
      reason: "applies EA protocol to manage snippet-to-page gap"
      contract: "expectation-architecture §Entrypoint receives follower URL and referral pathway from §EA application"
    - id: hidden-intent
      reason: "applies HI protocol to opening sequence at each refresh"
      contract: "hidden-intent §Intent classification receives follower URL and query type from §HI application"
    - id: costly-signal
      reason: "audits and upgrades trust signals at each refresh"
      contract: "costly-signal §Audit receives follower URL from §CS application"
    - id: memory
      reason: "logs optimisation events and refresh cycles"
      contract: "memory §Sites.[domain].Follower Log receives update on optimisation"
    - id: measurement-architecture
      reason: "follower success is tracked against Dimension 1 and 2 metrics"
      contract: "measurement-architecture §Dimension 1 and 2 receives follower performance data"

  called_by:
    - id: SKILL
      reason: "routes follower optimisation requests here"
      contract: "§Entrypoint receives routing from SKILL.md"
    - id: scout-bee
      reason: "graduating scouts pass their validated data here"
      contract: "§Entrypoint receives graduating scout data from scout-bee §Graduation procedure"
    - id: site-audit
      reason: "proven intent pages are assigned Follower role during audit"
      contract: "§Entrypoint receives proven-intent pages from site-audit §Role assignment"
    - id: feedback-loops
      reason: "triggers refresh cycle when SERP drift is detected"
      contract: "§Refresh cycle receives SERP drift signal from feedback-loops §Follower drift detection"

  chain_down:
    - id: colony-core
      relationship: "follower feeds colony-core checklist at refresh"
    - id: expectation-architecture
      relationship: "follower feeds EA protocol application"
    - id: hidden-intent
      relationship: "follower feeds HI protocol at each refresh"
    - id: memory
      relationship: "follower optimisation events log to memory"
  chain_up:
    - id: scout-bee
      relationship: "receives validated data from graduating scouts"
    - id: site-audit
      relationship: "receives proven-intent page assignments from audit"

  lateral:
    - id: memory-bee
      relationship: "follower pages with declining signals may be reclassified as memory assets"
    - id: measurement-architecture
      relationship: "follower performance data feeds Dimensions 1 and 2"
    - id: feedback-loops
      relationship: "follower drift detection triggers refresh here"
---

# Follower Bee — Exploitation Page Role

Followers are the colony's production pages. They exploit validated search demand with maximum reliability. Their job is not novelty — it is efficient capture of known intent. They carry most of the site's internal authority and most of the organic traffic.

A Follower gets this role in one of two ways: it was identified as a proven intent page during a site audit, or it graduated from Scout.

---

## Entrypoint

Receives from `SKILL.md`, `scout-bee.md §Graduation`, or `site-audit.md §Role assignment`:
- Page URL
- Current performance data if available (average position, clicks, impressions, CTR)
- Source (was this a graduated Scout or an existing page?)
- Hidden intent hypothesis (from scout graduation) or stated user problem (from audit)

Before proceeding: read `memory/memory.md §Sites.[domain].Follower Log` to check for existing optimisation history on this page.

---

## Initial follower setup (for graduated scouts or newly assigned pages)

Run these steps in order. Do not skip steps.

### Step 1 — Confirm intent match

Check the live SERP for the page's primary query. Ask:

- What is the dominant page type? (Guide / list / comparison / definition / tool / product page)
- What is the dominant content format? (Long-form prose / numbered steps / table / short answer)
- What is the dominant angle? (Beginner / expert / buyer / researcher)

If the page's current format does not match the dominant SERP format: flag for content redesign before optimisation. Content optimisation on a format mismatch is wasted effort.

**Output:** Intent match confirmed or format mismatch flagged.

### Step 2 — Hidden Intent Protocol application

Call `alchemy/hidden-intent.md §Intent classification` with the page URL and primary query.

Classify the likely hidden intent from the taxonomy (anxiety type, confusion type, justification-seeking, etc.). Apply hidden intent framing to:

- The opening sentence (must acknowledge the emotional state within the first paragraph)
- The H1 or page title (should address the anxiety, not only the keyword)
- The first subheading (should confirm the user is in the right place)

### Step 3 — Expectation Architecture application

Call `alchemy/expectation-architecture.md §Entrypoint` with:
- The page URL
- The primary referral pathway (organic SERP / social / email / referral)
- The current meta description and title tag

The EA protocol will identify whether the snippet promise matches the page's opening experience. Apply any corrections to the meta description, title, or opening sequence.

### Step 4 — Costly Signal audit

Call `alchemy/costly-signal.md §Audit` with the page URL.

Confirm at least two medium-to-high cost trust signals are present. If not, identify the cheapest available upgrade:
- At minimum: named author + dated update notice
- Target: named author + primary source citations + first-hand experience indicator

### Step 5 — Internal link choreography

Review the internal links on this page. For each link, confirm it does one of:

| Purpose | Test |
|---|---|
| Define | Does the linked page explain a term or concept used here? |
| Deepen | Does the linked page expand on something this page introduces? |
| Compare | Does the linked page offer a comparison this page mentions? |
| Route | Does the linked page serve a user who needs a different starting point? |
| Convert | Does the linked page serve a user ready to take action? |
| Troubleshoot | Does the linked page help a user who has hit a problem? |

Remove any internal links that fail all six tests. Add internal links from this Follower to relevant Scout and Outlier pages that have validated demand (depth is reciprocated — Scouts and Outliers must link back to this Follower as their authority source).

### Step 6 — Colony Core validation

Call `core/colony-core.md §Checklist` with the page URL. All C1–C10 must pass before the page is considered optimised. Fix any fails before logging the optimisation.

### Step 7 — Log to memory

Write to `memory/memory.md §Sites.[domain].Follower Log`:
- URL
- Optimisation type (initial setup / refresh / SERP drift response)
- Date
- Before state (position, clicks, impressions if known)
- After state (to be filled at next measurement point)

---

## Refresh cycle

Followers are refreshed when any of the following occur:

- SERP drift detected (`feedback-loops.md §Follower drift detection` triggers this)
- Significant content in the top-3 results has changed (manual monitoring or audit trigger)
- The page's average position drops more than 5 positions over 30 days
- A core algorithm update lands (run full refresh within 30 days)
- 6 months have elapsed since the last refresh (scheduled maintenance)

**Refresh procedure:**

1. Re-run Step 1 (Intent match) — has the SERP changed format or angle?
2. Re-run Counterfactual Content Test (`intelligence/counterfactual-test.md`) — does the page still add to the information set?
3. Update any outdated claims, broken examples, stale statistics, or dead external links
4. Check whether competitor pages have added something that makes this page comparatively weaker; if so, add it
5. Check whether an AI Overview now exists for the primary query; if so, apply AI extractability formatting (concise definitions, clean subheadings, explicit summaries)
6. Re-run colony-core checklist
7. Log refresh to memory

---

## Follower demotion

A Follower may be reclassified as a Memory asset when:

- Organic traffic has declined consistently for 6+ months despite two full refresh cycles
- The topic has been superseded by a newer, better Follower page
- The primary query now shows different intent that the page cannot satisfy without a fundamental rebuild

If demoting to Memory: brief `roles/memory-bee.md §Entrypoint` with the demotion reason and current link equity status.

---

## Success metrics

Tracked via `core/measurement-architecture.md §Dimension 1 and 2`:

- Average position in top 10 for primary intent query (Dimension 1 visibility)
- Organic click volume growth quarter-over-quarter (Dimension 1)
- Organic conversion rate from landing (Dimension 1)
- Scroll depth and time-on-page relative to content length (Dimension 2 cognitive friction proxy)
- Return visit rate (Dimension 2)
- Internal authority distributed vs. received (link equity balance)

---

## Link contracts

- `core/colony-core.md §Checklist` — receives follower URL from §Refresh cycle (this file calls colony-core)
- `intelligence/counterfactual-test.md §Entrypoint` — receives follower URL at each refresh (this file calls CCT)
- `alchemy/expectation-architecture.md §Entrypoint` — receives follower URL and referral pathway from §EA application (this file calls EA)
- `alchemy/hidden-intent.md §Intent classification` — receives follower URL and query type from §HI application (this file calls HI)
- `alchemy/costly-signal.md §Audit` — receives follower URL from §CS application (this file calls CS)
- `memory/memory.md §Sites.[domain].Follower Log` — receives optimisation updates (this file writes to memory)
- `roles/scout-bee.md §Graduation procedure` — supplies validated scout data to §Entrypoint (scout-bee calls this file)
- `roles/memory-bee.md §Entrypoint` — receives demotion briefing from §Follower demotion (this file calls memory-bee on demotion)
- `audit/feedback-loops.md §Follower drift detection` — supplies SERP drift signal to §Refresh cycle (feedback-loops calls this file)
