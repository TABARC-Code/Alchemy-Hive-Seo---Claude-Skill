/**
 * ALCHEMY-HIVE Skill Handler
 * 
 * Entrypoint for Claude skill integration.
 * Routes requests to the appropriate ALCHEMY-HIVE procedure.
 */

const fs = require('fs');
const path = require('path');

// Simple in-memory state for the skill's conversation context
const conversationState = {};

/**
 * Main request handler
 * Claude will call this with user input
 */
async function handleRequest(input, context = {}) {
  try {
    const sessionId = context.sessionId || 'default';
    
    // Load or create conversation memory for this session
    if (!conversationState[sessionId]) {
      conversationState[sessionId] = {
        startedAt: new Date(),
        lastAction: null,
        activeExperiments: [],
        siteContext: null,
      };
    }

    // Parse the user's request
    const request = parseRequest(input);
    
    // Route to the appropriate skill procedure
    const result = await routeRequest(request, sessionId);
    
    // Update conversation state
    conversationState[sessionId].lastAction = request.action;
    
    return {
      success: true,
      action: request.action,
      result: result,
      nextSteps: generateNextSteps(request.action),
      sessionId: sessionId,
    };
  } catch (error) {
    return {
      success: false,
      error: error.message,
      hint: 'Check SKILL.md for request format',
    };
  }
}

/**
 * Parse user input into a request object
 */
function parseRequest(input) {
  const lowerInput = input.toLowerCase().trim();
  
  // Simple pattern matching for common requests
  if (lowerInput.includes('audit')) {
    return { action: 'site-audit', type: 'audit' };
  }
  if (lowerInput.includes('scout')) {
    return { action: 'scout-brief', type: 'role' };
  }
  if (lowerInput.includes('follower')) {
    return { action: 'follower-optimization', type: 'role' };
  }
  if (lowerInput.includes('memory')) {
    return { action: 'memory-asset-management', type: 'role' };
  }
  if (lowerInput.includes('outlier')) {
    return { action: 'outlier-strategy', type: 'role' };
  }
  if (lowerInput.includes('alchemy') || lowerInput.includes('protocol')) {
    return { action: 'alchemy-protocol', type: 'alchemy' };
  }
  if (lowerInput.includes('waggle') || lowerInput.includes('research')) {
    return { action: 'waggle-dance-research', type: 'intelligence' };
  }
  if (lowerInput.includes('counterfactual') || lowerInput.includes('gate')) {
    return { action: 'counterfactual-test', type: 'intelligence' };
  }
  if (lowerInput.includes('hidden intent')) {
    return { action: 'hidden-intent-analysis', type: 'alchemy' };
  }
  if (lowerInput.includes('trivia')) {
    return { action: 'trivia-amplifier', type: 'alchemy' };
  }
  if (lowerInput.includes('logic-proof')) {
    return { action: 'logic-proof-detection', type: 'alchemy' };
  }
  if (lowerInput.includes('measure') || lowerInput.includes('measurement')) {
    return { action: 'measurement', type: 'core' };
  }
  if (lowerInput.includes('feedback') || lowerInput.includes('review')) {
    return { action: 'feedback-loop', type: 'audit' };
  }
  
  // Default: return routing help
  return { action: 'help', type: 'meta' };
}

/**
 * Route request to appropriate skill
 */
async function routeRequest(request, sessionId) {
  switch (request.action) {
    case 'site-audit':
      return {
        message: 'Site audit selected.',
        procedure: 'audit/site-audit.md',
        input_required: 'domain name or site URL',
        estimated_duration: '30-60 minutes',
        outputs: ['page-role-register', 'colony-core-checklist', 'audit-report'],
        next: 'Provide the domain to audit or load from memory.md for existing sites',
      };

    case 'scout-brief':
      return {
        message: 'Scout briefing selected.',
        procedure: 'roles/scout-bee.md',
        input_required: 'topic, unknown being tested, hidden intent hypothesis',
        estimated_duration: '15-20 minutes',
        outputs: ['scout-brief', 'memory-log-entry', 'pending-review-entry'],
        next: 'Describe the topic and what question you want the scout to test',
      };

    case 'follower-optimization':
      return {
        message: 'Follower optimization selected.',
        procedure: 'roles/follower-bee.md',
        input_required: 'URL or topic, current performance data if available',
        estimated_duration: '20-40 minutes per page',
        outputs: ['optimisation-checklist', 'internal-link-audit', 'memory-log-entry'],
        next: 'Provide the page URL and current average position or search volume',
      };

    case 'alchemy-protocol':
      return {
        message: 'Alchemy protocol selector.',
        procedure: 'alchemy/alchemy-router.md',
        input_required: 'page context and problem type',
        estimated_duration: '10-15 minutes',
        protocols_available: [
          'expectation-architecture',
          'hidden-intent',
          'costly-signal',
          'trivia-amplifier',
          'logic-proof-detector',
          'anti-waggle-dance',
          'adaptive-preference',
        ],
        next: 'Describe the page problem: "snippet to page gap", "users confused by topic", "page ranks but converts poorly", etc',
      };

    case 'waggle-dance-research':
      return {
        message: 'Waggle dance research initiated.',
        procedure: 'intelligence/waggle-dance.md',
        phases: ['standard tool scan', 'SERP landscape analysis', 'gap identification', 'anti-waggle extension'],
        estimated_duration: '20-30 minutes',
        outputs: ['signal-report', 'scout-brief-recommendations', 'memory-log-signals'],
        next: 'Provide the topic to research',
      };

    case 'counterfactual-test':
      return {
        message: 'Counterfactual Content Test gate.',
        procedure: 'intelligence/counterfactual-test.md',
        four_questions: [
          'Would the information landscape be meaningfully different without this page?',
          'Does a competitor page fully substitute for it?',
          'Does it contain at least one element not in top-5 SERP?',
          'Would reader be better equipped to act/decide/understand?',
        ],
        estimated_duration: '5-10 minutes',
        next: 'Provide page URL or topic description',
      };

    case 'measurement':
      return {
        message: 'Measurement architecture — five dimensions.',
        procedure: 'core/measurement-architecture.md',
        dimensions: [
          'Visibility (rankings, impressions, clicks, brand recall)',
          'Cognitive Friction (bounce, scroll depth, engagement)',
          'Trust Accumulation (backlinks, E-E-A-T signals)',
          'Adaptive Gain (scout/outlier graduation rates)',
          'Anti-Fragility Index (performance through updates)',
        ],
        estimated_duration: '30-45 minutes for full snapshot',
        next: 'Which dimension would you like to focus on, or run a full quarterly snapshot?',
      };

    case 'feedback-loop':
      return {
        message: 'Feedback loops — propagation rules.',
        procedure: 'audit/feedback-loops.md',
        triggerable_reviews: [
          'Scout 90-day reviews',
          'Outlier 120-day reviews',
          'Memory asset 6-month audits',
          'Follower SERP drift checks',
          'Trivia test results propagation',
        ],
        estimated_duration: '15-30 minutes per review event',
        next: 'Check pending reviews in memory.md or trigger a specific review type',
      };

    case 'help':
    default:
      return {
        message: 'ALCHEMY-HIVE skill — routing help.',
        hint: 'Try asking for:',
        common_requests: [
          '"audit [domain]" — run full site audit',
          '"scout [topic]" — brief a scout page',
          '"follower [URL]" — optimise a follower',
          '"alchemy [context]" — select protocol',
          '"waggle dance [topic]" — research demand signals',
          '"memory.md" — check system state',
          '"measurement" — five-dimension snapshot',
          '"feedback loops" — check pending reviews',
        ],
        full_docs: 'See README.md and SKILL.md for complete documentation',
      };
  }
}

/**
 * Generate next steps based on action
 */
function generateNextSteps(action) {
  const steps = {
    'site-audit': 'After audit: review page-role-register, check critical failures in colony-core results, prioritise content gaps from anti-waggle signals',
    'scout-brief': 'After brief: deploy page, set 90-day review calendar entry, monitor for success signals',
    'follower-optimization': 'After optimisation: run colony-core checklist, apply any protocols (EA, HI, CS), log to memory',
    'alchemy-protocol': 'Next: apply protocol to your page, measure results, feed back to memory for continuous learning',
    'waggle-dance-research': 'Next: review signal report, brief scouts from priority signals, update memory with discoveries',
    'counterfactual-test': 'Next: if fail, redesign per failing question; if pass, proceed to live deployment',
    'measurement': 'Next: compare snapshots quarterly, watch for Dimension 2 friction alerts, track Dimension 4 adaptive gain',
    'feedback-loop': 'Next: process all due reviews in pending calendar, write graduation logs, propagate wins to similar pages',
  };
  
  return steps[action] || 'See SKILL.md for full routing and procedures';
}

/**
 * Save conversation state to persistent storage
 * In a real Claude skill, this would use the platform's state management
 */
function saveState(sessionId) {
  // In production, write to context.persistentStorage or similar
  console.log(`State saved for session ${sessionId}`);
}

/**
 * Load conversation state from persistent storage
 */
function loadState(sessionId) {
  return conversationState[sessionId] || null;
}

// Export for use as a Node module
module.exports = {
  handleRequest,
  parseRequest,
  routeRequest,
  conversationState,
};

// If run directly, handle stdin
if (require.main === module) {
  const readline = require('readline');
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  const sessionId = `cli-session-${Date.now()}`;

  console.log('ALCHEMY-HIVE Skill Handler — CLI Mode');
  console.log('Type "exit" to quit, "help" for commands\n');

  rl.on('line', async (input) => {
    if (input.toLowerCase() === 'exit') {
      rl.close();
      process.exit(0);
    }

    const response = await handleRequest(input, { sessionId });
    console.log(JSON.stringify(response, null, 2));
    rl.prompt();
  });

  rl.setPrompt('> ');
  rl.prompt();
}
