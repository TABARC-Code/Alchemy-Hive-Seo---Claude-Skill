# CHANGELOG

All changes to ALCHEMY-HIVE. Newest first.

---

## v1.0.0 — initial build

First full release. Built from three source frameworks fused into one skill system.

**What's in:**

- SKILL.md master router with full request classification table and multi-skill chain definitions
- memory/memory.md persistent state file — every skill reads and writes here, nothing is lost between sessions
- core/colony-core.md — the ten determinate invariants (C1–C10), full checklist with pass/fail criteria and fix actions
- core/measurement-architecture.md — five-dimension measurement model covering visibility, cognitive friction, trust, adaptive gain, and anti-fragility
- roles/scout-bee.md — discovery page role with full brief template, graduation criteria, retirement criteria, and scout-to-outlier escalation
- roles/follower-bee.md — exploitation page role with initial setup procedure, seven-step optimisation chain, and drift refresh procedure
- roles/memory-bee.md — legacy asset role with decay diagnosis table, refresh/consolidate/retire decision tree, and scout-seeding procedure
- roles/outlier-bee.md — controlled deviation role with full alchemy protocol integration, 120-day review matrix, and outlier-to-scout pipeline
- intelligence/waggle-dance.md — structured research skill covering standard tool scan, SERP landscape analysis, gap identification, and anti-waggle extension
- intelligence/counterfactual-test.md — four-question publishing gate with decision matrix and special cases for refresh cycles
- alchemy/alchemy-router.md — protocol selector with routing decision table and full dispatch procedures
- alchemy/expectation-architecture.md — pre-click to on-page gap management, four-step audit and correction procedure
- alchemy/hidden-intent.md — anxiety-first framing with ten-entry intent taxonomy and three-element framing instructions
- alchemy/costly-signal.md — trust signal taxonomy across three cost tiers, audit procedure, and upgrade priority list
- alchemy/trivia-amplifier.md — small high-leverage intervention testing with hypothesis format and four-week measurement window
- alchemy/logic-proof-detector.md — four-round escalation (technical → content → authority → non-logical), six intervention types for Round 4
- alchemy/adaptive-preference.md — second-best position reframing with five situation types and specific copy/design correction format
- alchemy/anti-waggle-dance.md — seven non-tool signal sources (Reddit, Amazon reviews, competitor Q&A, SERP volatility, PAA, YouTube autocomplete, forum debates), confidence-tiered output
- audit/site-audit.md — six-phase full site audit procedure from page inventory through role assignments to pending review calendar
- audit/feedback-loops.md — complete propagation rules for every role transition, graduation chain, retirement chain, trivia win propagation, and reverse chain notation
- templates/page-role.yaml — page role assignment schema
- templates/scout-brief.md — scout brief template
- templates/audit-report.md — site audit output format
- templates/trivia-log.md — trivia amplifier experiment log

**Bidirectional link contracts:** every skill file declares its full link relationships in YAML front matter. A links to B; B explicitly acknowledges A. Chains are declared in both directions. Reverse flows (failure feedback, negative learning signals) are named and documented.

**Persistence:** memory.md is the single source of truth for system state. Nothing is thrown away — retirements, failures, and inconclusive results are documented with named reasons so the system learns from them.

---

*Nothing here has been scaffolded and left empty. All procedures are complete. Audit your work.*
