---
id: memory
version: "1.0"
layer: persistent-state

links:
  calls: []  # memory.md does not invoke other skills

  called_by:
    - id: SKILL
      reason: "reads at session start, writes at session end"
      contract: "§Active Sessions receives session log from SKILL.md routing events"
    - id: site-audit
      reason: "writes page role assignments and audit results"
      contract: "§Sites.[domain].Audit History receives full audit output"
    - id: scout-bee
      reason: "writes new scout deployment and 90-day review date"
      contract: "§Sites.[domain].Scout Log receives new entry on every scout deployment"
    - id: follower-bee
      reason: "writes follower optimisation events and refresh cycles"
      contract: "§Sites.[domain].Follower Log receives update on optimisation"
    - id: memory-bee
      reason: "writes memory asset refresh and retirement decisions"
      contract: "§Sites.[domain].Memory Asset Log receives audit outcome"
    - id: outlier-bee
      reason: "writes outlier hypothesis and 120-day review date"
      contract: "§Sites.[domain].Outlier Log receives new entry on every outlier deployment"
    - id: trivia-amplifier
      reason: "writes experiment hypothesis, result, and policy decision"
      contract: "§Protocol History.Trivia Amplifier Log receives entry per test"
    - id: logic-proof-detector
      reason: "writes escalation rounds and intervention decisions"
      contract: "§Protocol History.Logic-Proof Escalation Log receives entry per round"
    - id: feedback-loops
      reason: "writes graduation decisions and role transitions"
      contract: "§Protocol History.Graduation Log receives entry per decision"
    - id: alchemy-router
      reason: "writes protocol selection and application context"
      contract: "§Protocol History.Alchemy Applications receives entry per protocol use"
    - id: waggle-dance
      reason: "writes new signal discoveries"
      contract: "§Protocol History.Waggle Dance Signals receives signal report"

  chain_down: []  # memory.md is terminal — it does not chain forward
  chain_up:
    - id: SKILL
      relationship: "receives routing events from master"
    - id: all-role-skills
      relationship: "receives writes from all role and protocol skills"

  lateral:
    - id: SKILL
      relationship: "persistent bidirectional — SKILL reads and writes here every session"
---

# ALCHEMY-HIVE Memory

Persistent state file. Every skill reads from and writes to this file. It holds all active experiments, page role assignments, protocol history, and per-site audit records.

**Update format:** Add entries below the relevant section. Never delete entries — mark them as retired, graduated, or resolved with a date. The historical record is part of the value.

---

## System State

```
Framework version: 1.0
Initialised: [DATE]
Last session: [DATE]
Active sites: []
```

---

## Active Sessions

*Log of every SKILL.md routing event. Append below.*

| Date | Request type | Site | Skills activated | Outcome |
|---|---|---|---|---|
| — | — | — | — | — |

---

## Sites

*One subsection per site being tracked. Add a new site block when a first audit is run.*

### [domain.com]

**First audited:** [DATE]  
**Framework version at audit:** 1.0  
**Current page count (indexed):** —  
**Colony health score:** — / 5  

#### Page Role Register

*All pages with assigned roles. Updated by site-audit.md and feedback-loops.md.*

| URL | Role | Assigned | Review due | Status |
|---|---|---|---|---|
| — | — | — | — | — |

**Role count:**
- Scouts active: 0
- Followers active: 0
- Memory assets active: 0
- Outliers active: 0
- Unclassified: 0

#### Scout Log

*One entry per scout deployment. Updated by scout-bee.md and feedback-loops.md.*

| Scout URL | Topic tested | Hidden intent hypothesis | Deployed | Review due | Status | Outcome |
|---|---|---|---|---|---|---|
| — | — | — | — | — | Active | — |

**Status options:** Active / Review pending / Graduated / Retired / Escalated to Outlier

#### Follower Log

*Follower optimisation events. Updated by follower-bee.md.*

| URL | Optimisation type | Date | Before state | After state | Result |
|---|---|---|---|---|---|
| — | — | — | — | — | — |

#### Memory Asset Log

*Memory asset refresh and retirement decisions. Updated by memory-bee.md.*

| URL | Last refreshed | Refresh type | Link equity status | Entity ownership | Next audit |
|---|---|---|---|---|---|
| — | — | — | — | — | — |

#### Outlier Log

*Outlier hypothesis records. Updated by outlier-bee.md and feedback-loops.md.*

| URL | Alchemy protocol | Hypothesis | Deployed | Review due | Status | Outcome |
|---|---|---|---|---|---|---|
| — | — | — | — | — | Active | — |

**Status options:** Active / Review pending / Graduated to Follower / Retired / Converted to Scout agenda

#### Counterfactual Test Results

*Publishing gate outcomes. Updated by counterfactual-test.md.*

| Page/Idea | Q1 | Q2 | Q3 | Q4 | Decision | Date |
|---|---|---|---|---|---|---|
| — | — | — | — | — | Pass/Fail/Redesign | — |

#### Expectation Architecture Audit

*EA protocol applications. Updated by expectation-architecture.md.*

| URL | Primary referral pathway | Expectation set | Page resolves? | Gap severity | Action taken |
|---|---|---|---|---|---|
| — | — | — | — | — | — |

---

## Protocol History

### Trivia Amplifier Log

*One entry per experiment. Updated by trivia-amplifier.md.*

| ID | Site | Page URL | Intervention type | Hypothesis | Start date | End date | Result | Policy decision |
|---|---|---|---|---|---|---|---|---|
| TA-001 | — | — | — | — | — | — | — | — |

**Intervention types:** first-sentence / button-copy / URL-word-order / meta-description / anchor-text / internal-link-position / heading-word-choice / other

### Logic-Proof Escalation Log

*Escalation rounds for stuck pages. Updated by logic-proof-detector.md.*

| ID | Site | Page URL | Round 1 (technical) | Round 2 (content) | Round 3 (authority) | Logic-proof declared | Protocol E intervention | Outcome |
|---|---|---|---|---|---|---|---|---|
| LP-001 | — | — | — | — | — | — | — | — |

### Graduation Log

*Scout and Outlier role transitions. Updated by feedback-loops.md.*

| Date | Site | URL | From role | To role | Signal that triggered graduation | Notes |
|---|---|---|---|---|---|---|
| — | — | — | — | — | — | — |

### Alchemy Protocol Applications

*Every time an alchemy protocol is applied. Updated by alchemy-router.md.*

| Date | Site | Protocol | Page/Topic | Context | Hypothesis | Outcome (if known) |
|---|---|---|---|---|---|---|
| — | — | — | — | — | — | — |

### Waggle Dance Signals

*Non-standard demand signals discovered. Updated by waggle-dance.md and anti-waggle-dance.md.*

| Date | Site/Topic | Source type | Signal found | Action taken | Scout created? |
|---|---|---|---|---|---|
| — | — | Reddit / Amazon / Forum / SERP-volatility / PAA / YouTube-AC / Support | — | — | Y/N |

---

## Global Anti-Waggle-Dance Intelligence

*Signals not yet assigned to a specific site — general pattern observations.*

| Date | Signal source | Pattern observed | Potential application |
|---|---|---|---|
| — | — | — | — |

---

## Pending Reviews

*Auto-populated by scout-bee.md and outlier-bee.md. Checked by SKILL.md at session start.*

| Review type | Site | URL | Due date | Days remaining | Overdue? |
|---|---|---|---|---|---|
| Scout 90-day | — | — | — | — | N |
| Outlier 120-day | — | — | — | — | N |
| Memory 6-month | — | — | — | — | N |
| Follower SERP-drift | — | — | — | — | N |
| Trivia test 4-week | — | — | — | — | N |

---

## Notes

*Free-form session notes, observations, and hypotheses not captured by structured logs above.*

---

*End of memory.md — append entries; never overwrite*
