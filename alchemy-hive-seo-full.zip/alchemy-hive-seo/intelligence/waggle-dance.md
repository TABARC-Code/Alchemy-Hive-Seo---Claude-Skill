---
id: waggle-dance
version: "1.0"
layer: intelligence

links:
  calls:
    - id: anti-waggle-dance
      reason: "extends research to non-tool signal sources after standard tool scan"
      contract: "anti-waggle-dance §Entrypoint receives topic and initial tool signals from §Anti-waggle extension"
    - id: memory
      reason: "logs all discovered signals for the site and topic"
      contract: "memory §Protocol History.Waggle Dance Signals receives signal report"
    - id: scout-bee
      reason: "passes validated signals as scout brief inputs"
      contract: "scout-bee §Brief inputs receives signal report from §Signal output"

  called_by:
    - id: SKILL
      reason: "routes research requests here"
      contract: "§Entrypoint receives routing with topic from SKILL.md"
    - id: scout-bee
      reason: "scout briefs require signal sourcing before briefing"
      contract: "§Entrypoint receives topic from scout-bee §Brief inputs request"
    - id: site-audit
      reason: "site audit includes an anti-waggle scan of the site's topic space"
      contract: "§Entrypoint receives site topic space from site-audit §Anti-waggle scan"

  chain_down:
    - id: anti-waggle-dance
      relationship: "standard tool signals feed anti-waggle extension"
    - id: scout-bee
      relationship: "signal report feeds scout brief"
    - id: memory
      relationship: "signal discoveries log to memory"
  chain_up:
    - id: SKILL
      relationship: "receives routing from master"
    - id: site-audit
      relationship: "receives topic space from site audit"

  lateral:
    - id: anti-waggle-dance
      relationship: "bidirectional — waggle-dance feeds anti-waggle; anti-waggle feeds back unexpected signal types to update waggle-dance procedures"
---

# Waggle Dance — Structured Research and Signal Gathering

The waggle dance in the hive communicates direction and distance to food sources. In ALCHEMY-HIVE, this skill gathers and structures demand signals — from standard tools AND from sources the standard tools don't reach — and passes them to the scout briefing system.

It is also the point where the anti-waggle-dance protocol kicks in: the deliberate search for the signals that aren't in the standard tools.

---

## Entrypoint

Receives from `SKILL.md`, `scout-bee.md`, or `site-audit.md`:
- A topic, domain, or query cluster to research
- (Optional) An existing keyword list to extend or challenge
- (Optional) A specific unknown to probe (e.g., "we want to know if there is hidden demand for [subtopic]")

---

## Phase 1 — Standard tool scan

Run this even if you intend to go beyond the tools. You need to know what the tools say before you can identify what they miss.

### 1a. Core keyword intelligence

For the topic provided, collect:

- **Primary query** — the highest-volume, clearest-intent term for this topic
- **Secondary queries** — related terms with distinct intent (not just variations of the primary)
- **Question queries** — how users phrase this as a question ("how do I X", "why does X happen", "what is the best X for Y")
- **Comparison queries** — "X vs Y", "X alternative", "best X for [segment]"
- **Negative queries** — "X not working", "X problem", "X issues", "X failing"

For each query cluster, note:
- Approximate monthly search volume (if tool access available; if not, mark as "volume unknown")
- Trend direction (growing / stable / declining)
- Whether the site already has a page targeting this query
- Whether the site's existing page ranks in the top 30

### 1b. SERP landscape scan

For the top three queries identified above, examine the live SERP:

| SERP element | What to check |
|---|---|
| Dominant page type | Guide / list / comparison / definition / tool / product / forum |
| Dominant format | Prose / numbered steps / table / FAQ / short answer |
| Dominant angle | Beginner / expert / buyer / researcher / problem-solver |
| Featured snippets present? | Y/N — if Y, what format? (paragraph / list / table) |
| AI Overview present? | Y/N — if Y, what is it extracting? |
| People Also Ask visible? | Y/N — collect all PAA questions |
| Video results? | Y/N |
| SERP volatility | Do results change significantly day-to-day? (indicator of unsettled intent) |

### 1c. Gap identification

Compare the SERP landscape against the site's existing pages:

- Which query clusters have no existing site coverage? (Content gaps)
- Which site pages target a query but use the wrong format for the SERP? (Format mismatches)
- Which SERP positions are held by weak pages (thin content, poor trust signals, old dates)? (Competitive gaps)
- Which PAA questions have no good answer in the top results? (Answer gaps)

---

## Phase 2 — Anti-waggle extension

After the standard tool scan, call `alchemy/anti-waggle-dance.md §Entrypoint` with:
- The topic
- The standard tool findings (gaps, PAA questions, SERP volatility observations)
- Any specific query patterns that look promising but have low or unmeasured volume

Anti-waggle-dance will search for signals outside the tools and return additional findings. These are combined with the standard scan for the final signal report.

---

## Phase 3 — Signal report construction

Compile findings into a structured signal report. This is what gets passed to `scout-bee.md §Brief inputs`.

```
WAGGLE DANCE SIGNAL REPORT
Topic: [topic]
Site: [domain]
Date: [DATE]
Tool sources used: [list any keyword tools accessed, or "manual SERP analysis only"]

--- STANDARD SIGNALS ---

Primary query cluster:
  Query: [query]
  Volume: [number or "unknown"]
  Trend: [growing / stable / declining]
  Site coverage: [URL of existing page, or "none"]
  Existing position: [position or "not ranking"]
  Competitive gap: [Y/N — brief description]

Secondary query clusters:
  [repeat above for each secondary cluster]

SERP landscape (top 3 queries):
  Dominant page type: [type]
  Dominant format: [format]
  Featured snippet present: [Y/N, format if Y]
  AI Overview present: [Y/N, extraction type if Y]
  PAA questions collected: [list all questions]
  SERP volatility: [stable / moderate / high]

Identified gaps:
  Content gaps: [list query clusters with no site coverage]
  Format mismatches: [list pages with wrong format for their SERP]
  Competitive gaps: [list SERP positions held by weak pages]
  Answer gaps: [list PAA questions with no good existing answer]

--- ANTI-WAGGLE SIGNALS ---
[inserted from anti-waggle-dance.md output]

--- SCOUT BRIEF RECOMMENDATIONS ---

Priority 1 (highest signal quality): [query/topic — one sentence on why]
Priority 2: [query/topic]
Priority 3: [query/topic]

Hidden intent hypothesis per priority:
  P1: [anxiety type]
  P2: [anxiety type]
  P3: [anxiety type]

Recommended formats:
  P1: [format]
  P2: [format]
  P3: [format]
```

---

## Signal output

Pass the completed signal report to:
- `roles/scout-bee.md §Brief inputs` (primary destination — one scout brief per priority recommendation)
- `memory/memory.md §Protocol History.Waggle Dance Signals` (log for all discovered signals)

If the session was triggered by a site audit: also pass the signal report to `audit/site-audit.md §Anti-waggle scan results`.

---

## Negative feedback loop

If a scout built from a waggle-dance signal fails (with a named failure reason from `scout-bee.md §Retirement criteria`), that failure is fed back to this file's procedures as a learning signal:

- `no-demand` failures suggest the volume estimation from standard tools was wrong — increase scepticism about low-volume estimates
- `format-mismatch` failures suggest the SERP landscape scan missed a format shift — add a time-comparison check to the SERP scan
- `hidden-intent-wrong` failures suggest the intent classification from PAA questions was misleading — cross-check PAA against Reddit signals before classifying

These adjustments are noted in `memory/memory.md §Protocol History.Waggle Dance Signals` as procedure updates, not just failure records.

---

## Link contracts

- `alchemy/anti-waggle-dance.md §Entrypoint` — receives topic and initial tool signals from §Anti-waggle extension (this file calls anti-waggle)
- `alchemy/anti-waggle-dance.md §Output` — supplies non-tool signals back to §Signal report construction (anti-waggle calls back to this file)
- `memory/memory.md §Protocol History.Waggle Dance Signals` — receives signal report (this file writes to memory)
- `roles/scout-bee.md §Brief inputs` — receives signal report from §Signal output (this file calls scout-bee)
- `roles/scout-bee.md §Retirement criteria` — supplies failure reason back to §Negative feedback loop (scout-bee calls back to this file on failure)
- `audit/site-audit.md §Anti-waggle scan` — receives scan trigger (site-audit calls this file); returns signal report to site-audit
- `SKILL.md` — receives routing from master (SKILL calls this file)
