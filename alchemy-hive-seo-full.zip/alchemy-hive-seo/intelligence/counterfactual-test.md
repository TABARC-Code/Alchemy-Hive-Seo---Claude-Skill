---
id: counterfactual-test
version: "1.0"
layer: intelligence

links:
  calls:
    - id: memory
      reason: "logs all gate decisions"
      contract: "memory §Sites.[domain].Counterfactual Test Results receives outcome per test"

  called_by:
    - id: scout-bee
      reason: "gates scout publishing — scouts must pass before going live"
      contract: "§Entrypoint receives scout topic from scout-bee §Publishing gate"
    - id: follower-bee
      reason: "re-runs gate at each follower refresh cycle"
      contract: "§Entrypoint receives follower URL from follower-bee §Refresh cycle"
    - id: outlier-bee
      reason: "gates outlier publishing — outliers must pass despite unconventional nature"
      contract: "§Entrypoint receives outlier topic from outlier-bee §Publishing gate"
    - id: colony-core
      reason: "C8 (information gain) delegates full test procedure to this file"
      contract: "§Entrypoint receives page URL from colony-core §C8 check"
    - id: SKILL
      reason: "can be called directly for counterfactual requests"
      contract: "§Entrypoint receives routing from SKILL.md"

  chain_down:
    - id: memory
      relationship: "gate decisions log to memory"
  chain_up:
    - id: scout-bee
      relationship: "receives scout topics"
    - id: follower-bee
      relationship: "receives follower URLs at refresh"
    - id: outlier-bee
      relationship: "receives outlier topics"
    - id: colony-core
      relationship: "receives C8 check delegation"

  lateral:
    - id: hidden-intent
      relationship: "a page that passes CCT but targets only the literal query may still fail hidden intent — the two gates are complementary, not redundant"
---

# Counterfactual Content Test — Publishing Gate

Four questions. A page passes all four or it does not publish. Not a vibe check. A procedure.

The test applies to every new page and every Follower at each refresh cycle. Outliers must pass it too — being unconventional is not an excuse for adding nothing.

---

## Entrypoint

Receives from `scout-bee.md`, `follower-bee.md`, `outlier-bee.md`, `colony-core.md §C8`, or `SKILL.md`:
- Page URL (for existing pages) or topic/brief (for new pages)
- Available SERP data (what is currently ranking for the primary query?)
- Page draft or description

---

## The four questions

Run all four. A pass requires Yes to Q1, No to Q2, Yes to Q3, and Yes to Q4. Any other combination is a fail or redesign.

---

### Q1 — Would the information landscape be meaningfully different without this page?

**What to assess:**

Imagine the page does not exist. Would a person searching for the primary query get a materially worse result? Or would they find everything they need in the existing top-5 results?

"Meaningfully different" means:
- A unique angle, experience, or framework that does not exist in the top-5
- A format that better serves the intent than anything in the top-5 (e.g., a decision tool where the SERP only has articles)
- First-hand experience or original data that changes the information set
- A clearer or more honest treatment of a topic where existing results are vague or commercially biased

"Meaningfully different" does not mean:
- "Our version is better written" (unless the existing results are genuinely incomprehensible)
- "We cover the same ground but from our brand's perspective" (brand voice is not information gain)
- "We use a different structure" (structure alone is not a meaningful difference)

**Pass:** The page contributes something the top-5 do not contain.  
**Fail:** The top-5 already cover this ground adequately.

---

### Q2 — Does a competitor's closest existing page fully substitute for this one?

**What to assess:**

Find the closest competitor page to what you are planning to publish. Ask honestly: if a user read that page instead of yours, would they be missing anything important?

If the competitor's page fully substitutes — covers the same ground, at similar depth, with similar quality — then publishing a near-copy wastes resources and signals commodity content to Google's quality systems.

**Pass:** The competitor page is missing something the planned page would include.  
**Fail:** The competitor page would adequately substitute for the planned page.

---

### Q3 — Does this page contain at least one element not present in the top-5 SERP results?

**What to assess:**

Concretely identify the element. "One element" must be one of:

| Element type | Example |
|---|---|
| Original data | A survey result, test outcome, or dataset not published elsewhere |
| First-hand experience | Specific tested details only direct experience could produce |
| Original framework | A named structure, decision model, or taxonomy the author created |
| Unique synthesis | A connection between existing ideas that no current page makes |
| Honest correction | A factual correction to something the top-5 pages get wrong |
| Better decision support | A tool, calculator, or step-by-step that replaces a confusing explanation |
| Answer to an unanswered question | A PAA question or Reddit query that the top-5 don't address |

If you cannot name a specific element from this list that the planned page contains and the top-5 do not: the page fails Q3.

**Pass:** One element from the list above is present and verifiable.  
**Fail:** Cannot name a specific differentiating element.

---

### Q4 — Would a reader be measurably better equipped to act, decide, or understand after reading this?

**What to assess:**

A page is not information decoration. It has a job. After reading it, the user should be able to:

- Make a decision they couldn't make before (or make it with more confidence)
- Complete a task they were stuck on
- Understand something they were confused about in a way that changes their next action
- Avoid a mistake they would otherwise have made

"Measurably better equipped" means you can state the specific capability the user gains. Not "they'll know more about X" — that's decoration. "They'll be able to choose between A and B without anxiety about making the wrong choice" — that's a capability.

**Pass:** You can state one specific capability the user gains.  
**Fail:** The page informs but does not equip.

---

## Decision matrix

| Q1 | Q2 | Q3 | Q4 | Decision |
|---|---|---|---|---|
| Pass | Pass | Pass | Pass | ✓ PUBLISH |
| Fail | — | — | — | REDESIGN — identify differentiating element before proceeding |
| Pass | Fail | — | — | REDESIGN — competitor page substitutes; find the gap |
| Pass | Pass | Fail | — | REDESIGN — add one concrete differentiating element |
| Pass | Pass | Pass | Fail | REDESIGN — reframe around user capability, not information delivery |

**On redesign:** Do not start over. Identify the specific failing question and address only that. Re-run the test after redesign.

---

## Special cases

**For Follower refresh cycles:** If a previously-passing Follower now fails Q2 (competitor page fully substitutes), the Follower needs an information upgrade — not a rewrite. Find one element to add that the competitor lacks. This is the most common refresh failure.

**For Outliers:** If an Outlier page fails the CCT, the problem is usually Q3 or Q4. An unconventional format still needs to add something the SERP doesn't have and equip the user with a capability. Format novelty alone doesn't pass Q3.

**For Scout pages:** If the underlying topic fails Q1 (no meaningful gap exists), the scout brief should be revised before the page is written — not after.

---

## Output format

```
COUNTERFACTUAL TEST RESULT
Page/Topic: [URL or brief description]
Date: [DATE]
Called by: [scout-bee / follower-bee / outlier-bee / colony-core / SKILL]

Q1 — Meaningful difference: [PASS / FAIL]
  Reasoning: [one sentence]

Q2 — Competitor substitution: [PASS / FAIL]
  Closest competitor: [URL if known]
  Reasoning: [one sentence]

Q3 — Unique element: [PASS / FAIL]
  Element identified: [type and description, or "none identified"]

Q4 — User capability: [PASS / FAIL]
  Capability gained: [one sentence, or "cannot be stated"]

Decision: [PUBLISH / REDESIGN]
Redesign instruction (if applicable): [specific action needed — which question failed and what to add]
```

Log to `memory/memory.md §Sites.[domain].Counterfactual Test Results`.

---

## Link contracts

- `memory/memory.md §Sites.[domain].Counterfactual Test Results` — receives test outcome (this file writes to memory)
- `roles/scout-bee.md §Publishing gate` — receives CCT result back (scout-bee calls this file; this file returns decision)
- `roles/follower-bee.md §Refresh cycle` — receives CCT result back (follower-bee calls this file at refresh)
- `roles/outlier-bee.md §Publishing gate` — receives CCT result back (outlier-bee calls this file)
- `core/colony-core.md §C8` — receives CCT full test result (colony-core delegates C8 to this file)
