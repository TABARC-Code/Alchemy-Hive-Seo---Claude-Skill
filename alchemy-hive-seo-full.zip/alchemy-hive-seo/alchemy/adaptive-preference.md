---
id: adaptive-preference
version: "1.0"
layer: alchemy

links:
  calls:
    - id: memory
      reason: "logs AP applications and outcomes"
      contract: "memory §Protocol History.Alchemy Applications receives AP entry"
  called_by:
    - id: alchemy-router
      reason: "routes here for second-best position reframing"
      contract: "§Entrypoint receives context from alchemy-router §Routing decision AP"
    - id: logic-proof-detector
      reason: "calls AP as Round 4 non-logical intervention type"
      contract: "§Entrypoint receives stuck page context from logic-proof-detector §Round 4"
  chain_down:
    - id: memory
      relationship: "AP applications log to memory"
  chain_up:
    - id: alchemy-router
      relationship: "receives routing"
    - id: logic-proof-detector
      relationship: "receives Round 4 referral"
  lateral:
    - id: hidden-intent
      relationship: "resentment about a second-best position is a hidden intent type — AP and HI address complementary layers"
---

# Adaptive Preference Formation — Second-Best Position Reframing

When people are forced into option B over option A, they construct a narrative in which they prefer B anyway — if B has been designed to support that narrative. If B is unambiguously worse in every dimension, half the people are resentful. Design B so it has its own story, and the level of regret drops significantly.

Applied to SEO and web practice: the free tier, the fourth-ranked result, the brand-new site without authority, the non-market-leader — these are all "standing" positions. This protocol designs the standing position so users can tell themselves they chose it.

---

## Entrypoint

Receives: description of the second-best situation, current page or UX design, what the "best" position offers that this one currently lacks.

---

## Step 1 — Identify the second-best situation

Which of these applies?

| Situation | The "seated" position | The "standing" position |
|---|---|---|
| Free vs. paid tier | Paid: full features, priority support, no limits | Free: limited features, slower or no support, hard caps |
| Position 4–10 in SERP | Positions 1–3: authority, trust, familiarity | Position 4–10: less visible, less trusted by default |
| New/low-authority site | Established sites: history, link equity, brand recognition | New site: no history, no links, unknown brand |
| Non-market-leader brand | Market leader: first-mover advantage, wider integration, higher brand recall | Non-leader: smaller ecosystem, less name recognition |
| Limited-access trial | Full product: unrestricted | Trial: time-limited or feature-limited |

---

## Step 2 — Audit what the standing position currently signals

Read the current page or experience as a user who is NOT already enthusiastic about this option. What does the design communicate?

**Red flags (signals that create resentment):**

- The page leads with what the user *can't* have ("Upgrade to access all features")
- The free tier interface is visually degraded compared to the paid tier
- The trial constantly reminds the user it will end ("7 days remaining")
- The fourth-ranked result's snippet makes no claim to be different — it just looks like a weaker version of the top 3
- The new site's content acknowledges its own lack of authority ("We're new here, but...")
- The non-leader brand leads with its similarity to the market leader ("Like [Leader] but with...")

All of these prevent adaptive preference formation. The user cannot construct a narrative in which B is a genuine choice rather than a consolation.

---

## Step 3 — Design the standing position's own story

For each red flag identified in Step 2, apply a reframe:

### Free tier

| Current design (resentment) | AP design (choice) |
|---|---|
| "Upgrade to unlock X, Y, Z" | Feature the free tier's genuine advantages: no credit card, no lock-in, instant setup, no data harvested for upsell |
| Interface that looks degraded | Interface that looks different but intentionally clean — the free tier is the simple tier, and simplicity has its own value |
| Upgrade nag on every interaction | Remove upgrade prompts from within the workflow; confine them to a single prominent but optional section |

### Fourth-ranked result

| Current design | AP design |
|---|---|
| Snippet that says the same thing as positions 1–3 but weaker | Snippet that says something specific that positions 1–3 do not say — a different angle, a more honest framing, a specific detail |
| Title that competes on the same terms | Title that targets the user who has already read the top 3 and wasn't satisfied |
| Opening that tries to prove superiority | Opening that acknowledges "you might have already read other guides — here's what they missed" |

### New / low-authority site

| Current design | AP design |
|---|---|
| Apologetic tone or over-compensating claims | Lead with the advantages of newness: more current, unencumbered by legacy positions, willing to be honest where established players can't be |
| Sparse content that signals investment gap | Narrow the scope to what the site does exceptionally well; be the deepest source on a specific subtopic rather than the thinnest source on everything |
| Generic trust signals | First-hand experience signals are more credible than institutional authority for new sites — lead with specific tested detail |

### Non-market-leader

| Current design | AP design |
|---|---|
| "We're like [Leader] but..." | Never compare to the leader in your opening; define your own category |
| Feature comparison tables that highlight everything the leader has that you don't | Feature comparison tables that reframe the criteria — what matters if you're in your specific use case, not what matters for the general user |
| Price as the primary differentiator | Price is the weakest AP story; focus on specificity of fit ("built for [specific type of user]") instead |

---

## Step 4 — Apply the reframe

Produce specific copy and design instructions for the elements identified in Step 3. The output is not a tone direction — it is specific replacements.

Example output format:

```
AP REFRAME: Free tier
Page: [URL]

Element 1: Free tier hero section
Current: "Try [Product] Free — Upgrade anytime to unlock all features"
Reframe to: "Start building with [Product] — no credit card, no lock-in, works immediately"

Element 2: Feature list presentation
Current: Shows full feature list with locked items greyed out
Reframe to: Shows free tier feature list only — what the user has, not what they lack; link to separate comparison page for users actively considering upgrade

Element 3: Upgrade prompts
Current: Banner on every screen
Reframe to: Single "Compare plans" link in top navigation; no in-workflow interruptions
```

---

## Output format

```
AP APPLICATION
Situation: [type from Step 1]
Page/Product: [URL or description]
Date: [DATE]

Red flags identified:
  [list each resentment-creating element]

Reframes applied:
  [list each specific element change: current → reframe]

Hypothesis: "Applying AP reframes to [situation] will [reduce bounce / increase free-to-paid conversion / increase CTR from position 4 / other metric] because users will be able to construct a narrative in which [their situation] is a chosen position rather than a consolation."

Measurement metric: [specific metric to track]
Observation window: [DATE + 60 days]
```

Log to `memory/memory.md §Protocol History.Alchemy Applications`.

---

## Link contracts

- `memory/memory.md §Protocol History.Alchemy Applications` — receives AP entry (this file writes to memory)
- `alchemy/alchemy-router.md §Routing decision AP` — supplies context (alchemy-router calls this file)
- `alchemy/logic-proof-detector.md §Round 4` — supplies referral context (LPD calls this file as Round 4 intervention)
- `alchemy/hidden-intent.md` — lateral: resentment about a second-best position is a hidden intent type (specifically "forced-choice frustration") — AP and HI are complementary when this intent is present
