---
id: logic-proof-detector
version: "1.0"
layer: alchemy

links:
  calls:
    - id: memory
      reason: "logs each escalation round and intervention decision"
      contract: "memory §Protocol History.Logic-Proof Escalation Log receives entry per round"
    - id: colony-core
      reason: "runs colony-core checklist as Round 1 technical logic"
      contract: "colony-core §Checklist receives stuck page URL from §Round 1"
    - id: counterfactual-test
      reason: "runs CCT as part of Round 2 content logic"
      contract: "counterfactual-test §Entrypoint receives stuck page from §Round 2"
  called_by:
    - id: alchemy-router
      reason: "routes here for persistent underperformance"
      contract: "§Entrypoint receives context and intervention history from alchemy-router §Routing decision LPD"
    - id: SKILL
      reason: "can be called directly for logic-proof requests"
      contract: "§Entrypoint receives routing from SKILL.md"
  chain_down:
    - id: colony-core
      relationship: "Round 1 technical check"
    - id: counterfactual-test
      relationship: "Round 2 content check"
    - id: memory
      relationship: "escalation rounds log to memory"
  chain_up:
    - id: alchemy-router
      relationship: "receives routing with intervention history"
  lateral:
    - id: outlier-bee
      relationship: "Round 4 interventions may result in an outlier brief — non-logical strategy applied to a persistent underperformer"
    - id: feedback-loops
      relationship: "LPD escalation outcomes feed feedback-loops §Logic-proof resolution"
---

# Logic-Proof Detector — Non-Logical Escalation for Stuck Pages

When a page underperforms despite technically correct implementation, most practitioners respond with more of the same logic. If the problem has survived three rounds of logical intervention, it is likely logic-proof. The diagnostic then switches to non-logical intervention types.

---

## Entrypoint

Receives: page URL, history of interventions already run (from memory.md), current performance data.

First: check `memory/memory.md §Protocol History.Logic-Proof Escalation Log` for this URL. If a log entry already exists, continue from the highest completed round. If no entry exists, start at Round 1.

---

## Round 1 — Technical logic (60-day window)

Run `core/colony-core.md §Checklist` on the page.

**If any C1–C6 fail:** Fix them. Start the 60-day clock. Do not proceed to Round 2 until 60 days have elapsed post-fix.

**If all C1–C6 pass:** The technical layer is sound. The page is not being blocked by technical problems. Log Round 1 pass to memory and note the 60-day observation start date.

At 60 days: check if performance has improved. If yes — problem solved, log resolution. If no — proceed to Round 2.

---

## Round 2 — Content logic (60-day window)

Run four content checks:

1. **Intent match** — does the page format match the dominant SERP format for its primary query? (Check live SERP.)
2. **Counterfactual test** — run `intelligence/counterfactual-test.md`. Does the page still pass?
3. **Trust signals** — run `alchemy/costly-signal.md §Audit`. Is the trust signal score adequate?
4. **C7–C10 from colony-core** — is the user problem named? Is the information gain present? Is authorship clear? Are internal links purposeful?

**If any check fails:** Fix it. Start 60-day clock. Do not proceed to Round 3 until 60 days post-fix.

**If all checks pass:** The content layer is sound. Log Round 2 pass to memory.

At 60 days: check performance. Improved → solved. Not improved → Round 3.

---

## Round 3 — Authority logic (60-day window)

Run three authority checks:

1. **Internal link audit** — is this page receiving meaningful internal authority from high-value pages? Check: how many internal links point to this page? What is the role of those linking pages? Are any Followers or Memory assets pointing here?
2. **External backlink context** — are there any external referring domains? Are they contextually relevant? (A technology page with links only from unrelated directories carries weak authority.)
3. **Topical cluster coherence** — is this page part of a coherent topic cluster? Does it have siblings (Scout or Follower pages) that cover adjacent subtopics and link to this page?

**If any check fails:** Fix it. Start 60-day clock.

**If all checks pass:** The authority layer is sound. Log Round 3 pass to memory.

At 60 days: check performance. Improved → solved. Not improved → Round 4 (logic-proof declared).

---

## Round 4 — Logic-proof declared, non-logical intervention

The page has survived three rounds of logical intervention. The problem is likely not solvable with more of the same. Select one non-logical intervention type and apply it.

### Non-logical intervention types

**Narrative reframe**  
The page is informationally correct but the story it tells is wrong. Users are not connecting with the narrative arc.  
Action: Redesign the page's narrative structure. Start with the outcome, not the setup. Use the hidden intent framework to reframe around the user's actual emotional state. Apply `alchemy/hidden-intent.md`.

**Emotional register shift**  
The page's tone is misaligned with its audience's anxiety state.  
Action: Identify the emotional register of the top-performing competitor pages. Rewrite the opening sequence to match it. Test whether formal vs. conversational, confident vs. empathetic, or directive vs. exploratory is the right register for this specific hidden intent.

**Brand signal injection**  
The site has insufficient brand recognition for this page to benefit from the topical authority it has technically built. No amount of on-page optimisation compensates for zero brand search volume.  
Action: Focus external effort on brand building for 60–90 days before reassessing this page. PR, community, social presence, podcast appearances — anything that drives branded search volume. Then reassess.

**Format inversion**  
The page looks like everything else in the SERP. The non-logical move is to make it look unlike everything else.  
Action: If the SERP is dominated by long-form articles, publish a decision tool or a single-page reference. If the SERP is all lists, publish a deep narrative. The format itself becomes the differentiator. Brief an Outlier page with this strategy via `roles/outlier-bee.md`.

**Adaptive preference redesign**  
The page is serving users who are in a second-best position (not the top result, limited access, newer brand) and the design makes them feel resentful about it.  
Action: Apply `alchemy/adaptive-preference.md` to redesign the experience so users can construct a narrative about choosing it.

**Decision order reversal**  
There is a prerequisite in the user journey that is blocking action (the electric car / charging point problem).  
Action: Audit the user journey for decision-order problems. Is there a step the user must complete before taking the desired action that could be reordered? Fix the sequence.

---

## Output format

```
LOGIC-PROOF DETECTION REPORT
Page: [URL]
Date: [DATE]
Current round: [1 / 2 / 3 / 4]

Round 1 technical: [PASS / FAIL / in progress — date started]
Round 2 content: [PASS / FAIL / not yet run]
Round 3 authority: [PASS / FAIL / not yet run]
Round 4 declared: [Y / N]

If Round 4:
  Intervention type selected: [from list above]
  Reasoning: [one paragraph — why this intervention type for this page]
  Implementation instructions: [specific actions]
  120-day observation window starts: [DATE]
  Success criteria: [what improvement would indicate the intervention worked]
  Failure criteria: [what would confirm this intervention also failed]
```

Log to `memory/memory.md §Protocol History.Logic-Proof Escalation Log`.

---

## Link contracts

- `memory/memory.md §Protocol History.Logic-Proof Escalation Log` — receives entry per round (this file writes to memory)
- `core/colony-core.md §Checklist` — receives stuck page URL from §Round 1 (this file calls colony-core)
- `intelligence/counterfactual-test.md §Entrypoint` — receives stuck page from §Round 2 (this file calls CCT)
- `alchemy/costly-signal.md §Audit` — receives stuck page from §Round 2 authority check (this file calls CS)
- `alchemy/hidden-intent.md` — called on Narrative reframe intervention in Round 4
- `alchemy/adaptive-preference.md` — called on Adaptive preference redesign in Round 4
- `roles/outlier-bee.md §Entrypoint` — receives Format inversion brief from §Round 4 (this file calls outlier-bee on format inversion)
- `alchemy/alchemy-router.md §Routing decision LPD` — supplies context (alchemy-router calls this file)
