---
id: costly-signal
version: "1.0"
layer: alchemy

links:
  calls:
    - id: memory
      reason: "logs trust signal audits and upgrades"
      contract: "memory §Protocol History.Alchemy Applications receives CS entry"
  called_by:
    - id: alchemy-router
      reason: "routes here for trust gap strategy"
      contract: "§Entrypoint receives context from alchemy-router §Routing decision CS"
    - id: follower-bee
      reason: "audits trust signals at every follower setup and refresh"
      contract: "§Audit receives follower URL from follower-bee §CS application"
    - id: memory-bee
      reason: "refreshes trust signals on memory assets"
      contract: "§Audit receives memory asset URL from memory-bee §Signal refresh"
  chain_down:
    - id: memory
      relationship: "CS audits log to memory"
  chain_up:
    - id: alchemy-router
      relationship: "receives routing"
    - id: follower-bee
      relationship: "receives follower URL"
    - id: memory-bee
      relationship: "receives memory asset URL"
  lateral:
    - id: colony-core
      relationship: "C9 (trust signals) defers detailed taxonomy to this file; this file feeds C9 pass/fail criteria"
---

# Costly Signal — Trust Through Investment

Google's E-E-A-T framework is, at its operational level, a costly signalling system. Signals that demonstrate expertise, authoritativeness, and trustworthiness are not free to produce. That is their function. A site that deploys costly signals consistently outperforms one of equivalent informational quality that looks cheap.

---

## Entrypoint

Receives: page URL, current trust signals if known, competitive context if available.

---

## Signal taxonomy

### High-cost signals (most trust value, hardest to fake)

| Signal | What it looks like on the page | What to check |
|---|---|---|
| Original primary research | Documented methodology, dataset, survey results with sample size | Is the data original? Is the method described? Can it be independently verified? |
| Named expert authorship with off-site verification | Author name linked to a profile with publication history, credentials, or professional footprint | Does the linked profile exist? Does it have history predating this page? |
| First-hand tested experience | Specific product/service details only direct experience could produce (model numbers, specific failure modes, exact pricing at time of test) | Are the details specific enough that they couldn't be copied from a spec sheet? |
| Case studies with named outcomes | Named client or documented result with specifics | Are outcomes specific? Are they independently verifiable? |

### Medium-cost signals (good trust value, achievable)

| Signal | What it looks like | What to check |
|---|---|---|
| Dated publication with update changelog | "Published [date]. Last updated [date]. Changes: [brief note]." | Is the date honest? Does the changelog reflect real changes? |
| Primary source citations | Links to government data, peer-reviewed research, official documentation — not other blog posts | Do the citations link to primary sources? Do the links still resolve? |
| Author biographical detail | Specific enough to be verifiable — not "John is a passionate writer" but "John spent 8 years as a Zigbee installer across 200+ residential projects" | Can the biography be cross-referenced? Is it specific? |
| Methodology description | "We tested 12 devices over 30 days using [method]" | Is the method specific? Does it support the conclusions? |

### Low-cost signals (basic compliance, widely neglected)

| Signal | What it looks like | What to check |
|---|---|---|
| HTTPS | URL starts with https:// | SSL certificate valid and not expired |
| Dated update notice | "Last updated [date]" visible near top | Date is accurate |
| Professional visual design | Photography over stock images; consistent design system | Does the page look like an institution invested in it? |
| Schema markup — Author, Article, or relevant type | Structured data in source | Does it validate? Does it match visible content? |

---

## Audit procedure

For the page provided, score each tier:

**High-cost:** Count signals present (0–4). Minimum for Follower pages: 1. Target: 2.  
**Medium-cost:** Count signals present (0–4). Minimum for Follower pages: 2.  
**Low-cost:** Count signals present (0–4). All four should be present; if not, fix immediately.

**Total trust signal score:** [high count × 3] + [medium count × 2] + [low count × 1]

| Score | Assessment |
|---|---|
| 10+ | Strong — competitive in most SERP environments |
| 6–9 | Adequate — may struggle in high-stakes categories (health, finance, legal, major purchases) |
| 3–5 | Weak — susceptible to quality assessments in any competitive SERP |
| 0–2 | Critical — page looks anonymous and investment-free |

---

## Upgrade recommendations

Identify the cheapest available signal upgrade that would meaningfully improve the score:

1. If no author name is present: add one immediately (cost: zero; impact: medium)
2. If author name present but not linked: link to an external profile (cost: low; impact: medium-high)
3. If no publication date visible: add it (cost: zero; impact: low-medium)
4. If external links go to secondary sources: replace two with primary sources (cost: low; impact: medium)
5. If no first-hand experience indicators: add two specific details only testing could produce (cost: time; impact: high)
6. If no original data: this is the highest-value upgrade — commission a survey, run a test, or access a dataset (cost: significant; impact: very high)

---

## Output format

```
CS AUDIT
Page: [URL]
Date: [DATE]

High-cost signals present: [list or "none"]
Medium-cost signals present: [list or "none"]
Low-cost signals present: [list or "none"]

Trust signal score: [number]
Assessment: [Strong / Adequate / Weak / Critical]

Priority upgrades:
  1. [cheapest high-impact upgrade]
  2. [second upgrade]
  3. [third upgrade if needed]
```

Log to `memory/memory.md §Protocol History.Alchemy Applications`.

---

## Link contracts

- `memory/memory.md §Protocol History.Alchemy Applications` — receives CS entry (this file writes to memory)
- `alchemy/alchemy-router.md` — receives routing (alchemy-router calls this file)
- `roles/follower-bee.md §CS application` — supplies follower URL (follower-bee calls this file; this file returns audit + upgrade list)
- `roles/memory-bee.md §Signal refresh` — supplies memory asset URL (memory-bee calls this file)
- `core/colony-core.md §C9` — lateral: C9 defers to this file's taxonomy; this file feeds C9 pass/fail criteria
