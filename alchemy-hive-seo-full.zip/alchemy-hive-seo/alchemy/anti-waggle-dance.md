---
id: anti-waggle-dance
version: "1.0"
layer: alchemy

links:
  calls:
    - id: memory
      reason: "logs all non-tool signals discovered"
      contract: "memory §Protocol History.Waggle Dance Signals receives anti-waggle signal entry"
    - id: scout-bee
      reason: "passes high-confidence non-tool signals directly to scout briefing"
      contract: "scout-bee §Brief inputs receives non-tool signal from §Scout pipeline"

  called_by:
    - id: waggle-dance
      reason: "extends standard tool scan with non-tool signal sources"
      contract: "§Entrypoint receives topic and initial tool signals from waggle-dance §Anti-waggle extension"
    - id: SKILL
      reason: "can be called directly for anti-waggle research requests"
      contract: "§Entrypoint receives routing from SKILL.md"

  chain_down:
    - id: scout-bee
      relationship: "validated non-tool signals feed scout briefs"
    - id: memory
      relationship: "discoveries log to memory"
  chain_up:
    - id: waggle-dance
      relationship: "receives standard signal context from waggle-dance"

  lateral:
    - id: waggle-dance
      relationship: "bidirectional — anti-waggle output updates waggle-dance negative feedback loop; waggle-dance tool findings update anti-waggle source prioritisation"
    - id: outlier-bee
      relationship: "anti-waggle signals frequently seed outlier hypotheses"
    - id: hidden-intent
      relationship: "anti-waggle source material (Reddit, reviews) is primary raw material for hidden intent classification"
---

# Anti-Waggle-Dance — Demand Signals Outside the Tools

Every practitioner running the same keyword tools reads the same waggle dance. The railway station nobody has bought near is the demand that doesn't appear in the tools yet. This protocol finds it.

Anti-waggle-dance is called after the standard tool scan in `waggle-dance.md`. It searches seven source types for signals the tools miss.

---

## Entrypoint

Receives from `waggle-dance.md §Anti-waggle extension` or `SKILL.md`:
- Topic or domain being researched
- (Optional) Standard tool findings (gaps, PAA questions, SERP volatility notes)
- (Optional) A specific unknown: "we want to know if there's hidden demand for [subtopic]"

---

## Source 1 — Reddit thread language

**What you're looking for:** The exact words people use when they are confused, frustrated, or making decisions in public. Not the sanitised keyword version — the raw anxiety version.

**How to search:**
- Search Reddit for the topic using site-specific or community searches
- Target the communities where this topic's audience lives (identify the relevant subreddits)
- Focus on threads with high engagement (many comments, high upvotes) — these signal genuine shared anxiety
- Look specifically for: questions that have no satisfying answer in the replies; threads where multiple people express the same confusion; "I've tried everything" posts; "which is better" debates that stay unresolved

**What to extract:**
- Specific phrases or questions that don't appear in keyword tools
- The emotional register of the discussion (frustrated / overwhelmed / confused / excited but uncertain)
- The specific failure points people describe (these are hidden intent gold)
- Questions people ask before they're ready to search Google (upstream intent)

**Output format:**
```
Reddit signals for [topic]:
  Community: [subreddit or community name]
  Thread pattern: [description of the dominant concern]
  Exact phrases observed: ["phrase 1", "phrase 2", "phrase 3"]
  Hidden intent classification: [anxiety type from hidden-intent.md taxonomy]
  Estimated specificity: [very specific / moderately specific / broad]
  Keyword tool match: [found in tools / not in tools / partially in tools]
```

---

## Source 2 — Amazon and product review corpora

**What you're looking for:** The failure points and anxieties embedded in one-star and three-star reviews for products in this topic space. These are the exact concerns a page should address.

**How to search:**
- Find the top-selling products in this topic's space on Amazon (or equivalent)
- Read the 1-star reviews: what failed? What was misunderstood? What was the buyer hoping for?
- Read the 3-star reviews: what was the compromise? What worked and what didn't?
- Read the Q&A sections: what do buyers ask before purchasing that the product descriptions don't answer?

**What to extract:**
- Specific failure modes people describe
- Expectations vs. reality gaps
- Questions asked pre-purchase that aren't answered in the product listing (these are content opportunities)
- Language patterns (the exact nouns, verbs, and adjectives reviewers use)

---

## Source 3 — Competitor Q&A and comment sections

**What you're looking for:** The questions the market leader cannot or does not answer well — these are vacuums.

**How to search:**
- Find the top 3 competitor pages for the primary query
- Read all comments and Q&A sections
- Look for questions that received no answer, a vague answer, or an answer that generated further questions
- Look for corrections and disagreements in comments — these indicate where the page was wrong or incomplete

**What to extract:**
- Unanswered questions
- Corrections to the competitor's content (what the competitor got wrong = what you can get right)
- Recurring questions across multiple competitor pages (systemic gaps in the topic coverage)

---

## Source 4 — SERP volatility monitoring

**What you're looking for:** Queries where the top results change significantly — these indicate unsettled intent that hasn't been well-served yet.

**How to assess:**
- For the primary query and top secondary queries: note the current top-5 results
- If possible, compare against SERP snapshots from 3–6 months ago (archive tools or memory)
- High volatility = Google hasn't found a satisfying result yet = opportunity

**Output:**
- Volatility level: stable / moderate / high
- Whether the volatility is format-driven (Google cycling through different page types) or content-driven (similar pages cycling in and out)
- Whether any AI Overview is present and whether it cites a specific source consistently

---

## Source 5 — People Also Ask deep extraction

**What you're looking for:** The sub-questions Google surfaces reveal the full shape of an intent landscape, including questions that don't appear in standard keyword tools.

**How to extract:**
- Search the primary query and expand all visible PAA boxes
- Click on one PAA question to trigger a new set of related questions
- Repeat until no new question types appear
- Collect all unique questions

**What to look for:**
- Questions that no existing top-ranking page answers well
- Questions that reveal upstream intent (the question someone asks before the main query)
- Questions that reveal downstream intent (the question someone asks after getting the main answer)
- Questions where the PAA answer is thin, outdated, or from an unrelated source

---

## Source 6 — YouTube and Pinterest autocomplete

**What you're looking for:** Different query populations from Google text search. Visual and video search surfaces different anxieties and different formats of intent.

**How to search:**
- Type the primary topic into YouTube's search bar and record the autocomplete suggestions
- Type the primary topic into Pinterest's search bar and record suggestions
- Compare these against Google autocomplete — the differences reveal segments of the audience that aren't well-captured by text-search keyword tools

**What to look for:**
- Autocomplete suggestions that appear in YouTube but not in Google (format-specific demand)
- Visual search queries that indicate the user wants to SEE something, not read about it
- Tutorial and how-to variants that suggest a different intent slice

---

## Source 7 — Forum debates and community disagreements

**What you're looking for:** Topics in active dispute are topics with insufficient definitive content.

**How to search:**
- Search "[topic] debate" or "[topic] controversy" or "[topic] vs" in Google and filter for forum results
- Look at Quora, Stack Exchange, specialist forums relevant to the topic
- Look for questions that have multiple conflicting high-vote answers

**What to extract:**
- The specific point of contention (this is the content opportunity)
- Which side of the debate has better evidence (an opportunity to be the definitive source)
- Whether the dispute is about facts (resolvable with research) or preferences (requires a framework that acknowledges both sides)

---

## Signal assessment and output

After running all seven sources, assess each signal:

**Confidence tiers:**

| Tier | Criteria | Action |
|---|---|---|
| High | Signal appears in 3+ sources; specific phrase identified; clear hidden intent; no keyword tool match | Direct scout brief |
| Medium | Signal appears in 1–2 sources; clear pattern but less specific; may have partial keyword tool coverage | Scout brief with lower priority; add to outlier consideration |
| Low | Single source; vague pattern; unclear intent | Log to memory for monitoring; do not brief yet |

**Scout pipeline:**
For every High-confidence signal: call `roles/scout-bee.md §Brief inputs` with the signal data formatted as a scout brief input.

**Memory log:**
For every signal (all tiers): log to `memory/memory.md §Protocol History.Waggle Dance Signals` with:
- Signal source type
- Specific signal observed
- Confidence tier
- Action taken

---

## Feedback to waggle-dance

After completing the anti-waggle scan, report back to `waggle-dance.md §Signal report construction` with:
- All high-confidence signals formatted for inclusion in the signal report
- Any source types that were particularly productive for this topic (feeds waggle-dance source prioritisation)
- Any source types that yielded nothing (also useful — narrows future research)

---

## Link contracts

- `memory/memory.md §Protocol History.Waggle Dance Signals` — receives signal entry per discovery (this file writes to memory)
- `roles/scout-bee.md §Brief inputs` — receives high-confidence signals from §Scout pipeline (this file calls scout-bee)
- `intelligence/waggle-dance.md §Anti-waggle extension` — receives topic and tool context (waggle-dance calls this file)
- `intelligence/waggle-dance.md §Signal report construction` — receives anti-waggle output (this file calls back to waggle-dance after completion)
- `alchemy/hidden-intent.md` — lateral: anti-waggle source material (Reddit, reviews) is the primary raw material for hidden intent taxonomy; hidden-intent taxonomy updates anti-waggle classification criteria
- `roles/outlier-bee.md` — lateral: high-confidence anti-waggle signals frequently seed outlier hypotheses rather than scout briefs
