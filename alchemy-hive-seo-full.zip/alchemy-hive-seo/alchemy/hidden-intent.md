---
id: hidden-intent
version: "1.0"
layer: alchemy

links:
  calls:
    - id: memory
      reason: "logs intent classification and framing decisions"
      contract: "memory §Protocol History.Alchemy Applications receives HI entry"
  called_by:
    - id: alchemy-router
      reason: "routes here for anxiety-first framing strategy"
      contract: "§Entrypoint receives context from alchemy-router §Routing decision HI"
    - id: follower-bee
      reason: "applies HI at every follower setup and refresh"
      contract: "§Intent classification receives follower URL and query type from follower-bee §HI application"
    - id: scout-bee
      reason: "scouts include hidden intent hypothesis — this file classifies it"
      contract: "§Intent classification receives scout topic from scout-bee §Brief inputs"
  chain_down:
    - id: memory
      relationship: "classifications log to memory"
  chain_up:
    - id: alchemy-router
      relationship: "receives routing"
    - id: follower-bee
      relationship: "receives follower URL and query"
    - id: scout-bee
      relationship: "receives scout topic"
  lateral:
    - id: anti-waggle-dance
      relationship: "anti-waggle source material (Reddit, reviews) is primary raw material for HI classification; HI taxonomy updates anti-waggle classification criteria"
    - id: expectation-architecture
      relationship: "EA manages pre-click promise; HI manages on-page anxiety — sequential"
---

# Hidden Intent — Anxiety-First Content Framing

Standard intent taxonomy — informational, navigational, transactional — describes the surface query. It does not describe the psychological state beneath it. Hidden intent is the emotional or cognitive condition that the query symptomises.

A page that answers the literal keyword but not the underlying hesitation may rank briefly and fail to hold attention.

---

## Entrypoint

Receives: page URL or topic, primary query, any Reddit or review corpus signals if available.

---

## Intent classification

For the query provided, identify the primary hidden intent from the taxonomy below. A query may have secondary hidden intents; identify one primary.

| Query surface pattern | Hidden intent type | Emotional register | What the page must do |
|---|---|---|---|
| "Best X" | Comparison paralysis | Overwhelmed, afraid of wrong choice | Reduce the decision space; give a clear recommendation; validate that the choice matters but is survivable |
| "X vs Y" | Justification-seeking | Decision already made; seeking permission | Confirm the decision is sensible; provide specific reasons that feel like the user's own reasoning |
| "How to X" | Competence uncertainty | Uncertain of capability; shame avoidance | Reassure that X is achievable; give the first step before the overview |
| "Is X worth it" | Budget anxiety + social proof | Afraid of wasting money; seeking permission from authority | Give a concrete honest answer; cite real costs; acknowledge the risk |
| "X not working" | Frustration + fear of intractability | Annoyed; afraid the problem is unsolvable | Acknowledge the frustration in the opening; name the most common causes fast |
| "X for beginners" | Imposter syndrome | Worried about looking stupid; wants a safe on-ramp | Don't start with theory; start with the first practical action |
| "X alternative" | Distrust of market leader | Exit-seeking; burned or suspicious | Don't oversell; acknowledge why they might want an alternative; be honest about trade-offs |
| "X review" | Purchase risk anxiety | Afraid of buyer's remorse | Lead with a verdict; support with specifics; name who it's not for as well as who it is |
| "X problems" | Validation-seeking | Afraid they're uniquely struggling | Name the problem pattern immediately; confirm it's common; then diagnose |
| "Can I X" | Permission-seeking | Unsure if they're allowed or capable | Give the answer in the first sentence; explain after |

---

## Framing instructions

Once the primary hidden intent is classified, apply framing to three elements:

### H1 / page title
Shift from keyword description to anxiety acknowledgement. The title should make the user feel seen, not indexed.

| Keyword-first (wrong) | Anxiety-first (right) |
|---|---|
| "Best Smart Lights 2025" | "Choosing Smart Lights Without Regretting It Later" |
| "Home Assistant vs Google Home" | "Home Assistant vs Google Home: What Nobody Tells You Before You Switch" |
| "How to Set Up Zigbee" | "Zigbee Setup for Normal People (Not Just Home Automation Obsessives)" |

The anxiety-first title is not clickbait. It is an honest signal to the right user.

### Opening paragraph
The first paragraph must do three things in this order:

1. **Name the situation** — "If you're looking at X, you've probably noticed that [the frustration / confusion / overwhelm]."
2. **Validate the situation** — "That's because [brief honest reason] — it's not obvious."
3. **Set the resolution** — "This page [specific thing it does] so you can [specific capability gained]."

This takes about four sentences. Do not use more than six.

### First subheading
The first subheading should answer the question the user is really asking, not the keyword the page is optimised for. If the keyword is "best smart lights" and the hidden intent is comparison paralysis, the first subheading is not "The Best Smart Lights in 2025" — it might be "The Only Three Things That Actually Matter When Choosing Smart Lights."

---

## Output format

```
HI CLASSIFICATION
Page/Topic: [URL or description]
Primary query: [query]
Date: [DATE]

Primary hidden intent: [type from taxonomy]
Emotional register: [in 5 words]
Confidence: [high / medium / low]
Signal source: [what evidence supports this classification? keyword pattern / Reddit signal / review corpus / intuition]

Framing instructions:
  H1 suggestion: [revised title]
  Opening paragraph: [3-5 sentence draft applying the three-step formula]
  First subheading: [anxiety-addressing subhead]
```

Log to `memory/memory.md §Protocol History.Alchemy Applications`.

---

## Negative feedback

If a page with HI framing applied still shows poor engagement (high bounce, low scroll depth), the classification may be wrong. Revisit:

1. Was the emotional register identified correctly?
2. Is the opening paragraph naming a situation the user actually recognises?
3. Is the hidden intent type the primary one, or was a secondary intent more important?

Document the reassessment in memory and update the classification.

---

## Link contracts

- `memory/memory.md §Protocol History.Alchemy Applications` — receives HI log entry (this file writes to memory)
- `alchemy/alchemy-router.md §Routing decision HI` — supplies context (alchemy-router calls this file)
- `roles/follower-bee.md §HI application` — supplies follower URL and query (follower-bee calls this file; this file returns framing instructions)
- `roles/scout-bee.md §Brief inputs` — supplies scout topic for intent classification (scout-bee calls this file)
- `alchemy/anti-waggle-dance.md` — lateral: anti-waggle raw material feeds HI classification; HI taxonomy updates anti-waggle source criteria
- `alchemy/expectation-architecture.md` — lateral: EA manages pre-click; HI manages on-page anxiety; sequential when both applied
