---
id: trivia-amplifier
version: "1.0"
layer: alchemy

links:
  calls:
    - id: memory
      reason: "logs every experiment hypothesis and result"
      contract: "memory §Protocol History.Trivia Amplifier Log receives entry per experiment"
  called_by:
    - id: alchemy-router
      reason: "routes here for small high-leverage intervention testing"
      contract: "§Entrypoint receives context from alchemy-router §Routing decision TA"
    - id: SKILL
      reason: "can be called directly for trivia amplifier requests"
      contract: "§Entrypoint receives routing from SKILL.md"
  chain_down:
    - id: memory
      relationship: "experiment log entries write to memory"
  chain_up:
    - id: alchemy-router
      relationship: "receives routing"
  lateral:
    - id: hidden-intent
      relationship: "TA failures often reveal hidden intent mismatches — failed TA tests feed HI reassessment"
    - id: feedback-loops
      relationship: "TA results feed feedback-loops §Trivia result propagation for policy decisions"
---

# Trivia Amplifier — High-Leverage Small Interventions

In complex adaptive systems, proportionality does not hold. Small interventions produce disproportionate effects. Most SEO practitioners ignore trivial changes because they look too small to matter. That is the competitive advantage.

This protocol identifies, tests, and logs small interventions. Wins become policy. Losses feed the hidden intent diagnostic.

---

## Entrypoint

Receives: page URL, current performance metrics (conversion rate, engagement signals, CTR), any candidate interventions already identified.

---

## Known high-leverage intervention categories

### Pre-click (SERP level)

| Intervention | What to change | Why it might matter |
|---|---|---|
| Title tag opening | The first 3 words of the title | Users scan titles left-to-right; first words carry disproportionate weight |
| Title tag format | Question vs. statement vs. list promise | Format signals match SERP expectations differently |
| Meta description final clause | The last sentence, specifically its verb | The final clause often carries the call-to-action or benefit signal |
| Date presence | Adding or removing a date from the snippet | Dates signal recency (positive) or staleness (negative) depending on topic |
| Number in title | "7 ways" vs. "How to" vs. no number | Numbered lists signal scope; how-to signals process; neither signals depth |

### On-page opening sequence

| Intervention | What to change | Why it might matter |
|---|---|---|
| First sentence subject | "Smart lights can be confusing" vs. "If your smart lights keep disconnecting..." | Second-person immediate situation vs. third-person observation changes identification |
| Opening verb tense | Present tense imperative ("Choose your smart lights based on...") vs. future promise ("This guide will help you...") | Imperative creates momentum; promise creates delay |
| First paragraph length | 1 sentence vs. 3 sentences vs. 5 sentences | Shorter opening = faster value delivery = lower early bounce |
| H2 framing after intro | Keyword-describing H2 vs. anxiety-addressing H2 | (See hidden-intent.md for framing alternatives) |

### Navigation and action elements

| Intervention | What to change | Why it might matter |
|---|---|---|
| Button copy | "Submit" → "Get my [specific thing]" | Descriptive copy outperforms generic copy consistently |
| Decision order | Step A requires completing Step B first | Reversing a prerequisite can unblock a funnel entirely |
| CTA position | Below fold vs. above fold vs. repeated | Position relative to the point of conviction varies by intent |
| Free tier framing | What it lacks vs. what it has | (See adaptive-preference.md for this specific case) |

### Internal linking

| Intervention | What to change | Why it might matter |
|---|---|---|
| Anchor text specificity | "Read more" → "How to set up Zigbee without a hub" | Descriptive anchors tell both users and crawlers what they're getting |
| Link position in body | Sidebar widget vs. inline body text | Inline contextual links receive more clicks and carry more authority signal |
| Number of outbound links from page | More vs. fewer | Fewer focused links carry more authority per link |

---

## Experiment procedure

Test one intervention at a time. Never test two simultaneously on the same page — you won't know which caused the result.

### Hypothesis format

```
TRIVIA AMPLIFIER EXPERIMENT
ID: TA-[number]
Site: [domain]
Page: [URL]
Date started: [DATE]
Review date: [DATE + 28 days]

Intervention type: [from category list above]
Specific change: [exactly what is being changed, in one sentence]
From: "[exact current text/element]"
To: "[exact proposed text/element]"

Hypothesis: "Changing [X] to [Y] will [increase/decrease] [metric] because [reasoning based on known psychological or informational principle]"
Metric to measure: [CTR / conversion rate / scroll depth / time on page / bounce rate / clicks]
Measurement source: [Google Search Console / analytics platform / heatmap tool]

Baseline measurement: [current value of the metric, taken before the change]
```

### Four-week measurement window

After 28 days, compare the metric against baseline. Allow a minimum of 28 days — shorter windows are too noisy for meaningful signal.

**Measurement comparison:**

```
TRIVIA AMPLIFIER RESULT
ID: TA-[number]
Date measured: [DATE]

Baseline: [value]
Post-change: [value]
Delta: [+ or - and magnitude]
Direction: [improved / worsened / no change]
Confidence: [high (>20% delta) / medium (10-20% delta) / low (<10% delta)]

Policy decision:
  Win (improved, medium-high confidence): PROMOTE TO POLICY — apply this intervention type to similar pages
  Loss (worsened, medium-high confidence): RETIRE — document; feed into HI reassessment
  Inconclusive (low confidence or no change): EXTEND 14 days or RETIRE with note

If win — similar pages to update: [list URLs]
If loss — hidden intent reassessment triggered: [Y/N — log in HI if Y]
```

---

## Policy promotion

When an intervention wins:
1. Log the win to `memory/memory.md §Protocol History.Trivia Amplifier Log` with full result
2. Identify similar pages that would benefit from the same intervention
3. Apply the winning intervention to all similar pages (not another test — this is policy now)
4. Note in memory which pages received the policy application and the date

When an intervention loses:
1. Log the loss to memory with the full result and the reasoning that turned out to be wrong
2. If the failure suggests the hidden intent classification was incorrect: call `alchemy/hidden-intent.md §Intent classification` with the page and the failure data
3. If the failure was purely about the specific change and not the intent classification: document and close

---

## Link contracts

- `memory/memory.md §Protocol History.Trivia Amplifier Log` — receives experiment entry and result (this file writes to memory)
- `alchemy/alchemy-router.md §Routing decision TA` — supplies context (alchemy-router calls this file)
- `SKILL.md` — receives routing from master
- `alchemy/hidden-intent.md §Intent classification` — receives failure data for reassessment when TA loses (this file calls HI on loss)
- `audit/feedback-loops.md §Trivia result propagation` — receives win for policy propagation (this file calls feedback-loops on win)
