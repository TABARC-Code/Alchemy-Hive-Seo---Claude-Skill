---
id: alchemy-router
version: "1.0"
layer: alchemy

links:
  calls:
    - id: expectation-architecture
      reason: "routes to EA when snippet-to-page gap is identified"
      contract: "expectation-architecture §Entrypoint receives context from §Routing decision EA"
    - id: hidden-intent
      reason: "routes to HI when anxiety-first framing is the strategy"
      contract: "hidden-intent §Entrypoint receives context from §Routing decision HI"
    - id: costly-signal
      reason: "routes to CS when trust signal investment is the strategy"
      contract: "costly-signal §Entrypoint receives context from §Routing decision CS"
    - id: trivia-amplifier
      reason: "routes to TA when small high-leverage intervention is the target"
      contract: "trivia-amplifier §Entrypoint receives context from §Routing decision TA"
    - id: logic-proof-detector
      reason: "routes to LPD when persistent underperformance is the problem"
      contract: "logic-proof-detector §Entrypoint receives context from §Routing decision LPD"
    - id: anti-waggle-dance
      reason: "routes to AW when non-tool demand discovery is the strategy"
      contract: "anti-waggle-dance §Entrypoint receives context from §Routing decision AW"
    - id: adaptive-preference
      reason: "routes to AP when second-best position reframing is needed"
      contract: "adaptive-preference §Entrypoint receives context from §Routing decision AP"
    - id: memory
      reason: "logs every protocol selection and application context"
      contract: "memory §Protocol History.Alchemy Applications receives entry per use"

  called_by:
    - id: SKILL
      reason: "routes alchemy requests here"
      contract: "§Entrypoint receives routing from SKILL.md"
    - id: outlier-bee
      reason: "outlier briefs require protocol selection before brief construction"
      contract: "§Entrypoint receives outlier context from outlier-bee §Protocol selection"
    - id: follower-bee
      reason: "follower refresh cycles call alchemy protocols EA, HI, and CS"
      contract: "§Entrypoint receives follower URL and context from follower-bee"

  chain_down:
    - id: "[selected protocol]"
      relationship: "routes to whichever protocol matches the context"
    - id: outlier-bee
      relationship: "returns selected protocol to outlier-bee for brief construction"
    - id: memory
      relationship: "selection event logs to memory"
  chain_up:
    - id: SKILL
      relationship: "receives routing"
    - id: outlier-bee
      relationship: "receives outlier context for protocol selection"

  lateral:
    - id: all-alchemy-protocols
      relationship: "bidirectional: router dispatches; protocols return outcomes; outcomes update router's selection heuristics"
---

# Alchemy Router — Protocol Selector

Seven alchemy protocols exist. This router selects the right one given the context. For outlier page briefs, it selects and returns the protocol. For direct alchemy requests, it dispatches to the protocol and manages the output.

---

## Entrypoint

Receives from `SKILL.md`, `outlier-bee.md §Protocol selection`, or `follower-bee.md`:
- Context: what is the problem or strategy?
- Page URL (if existing page)
- Topic (if new page)
- Any available performance data
- Preferred protocol (optional — user may specify; if specified, validate and dispatch)

---

## Protocol selection matrix

Read the context and match to the first applicable row.

| Primary signal in context | Protocol selected | Why |
|---|---|---|
| "Users click the snippet but bounce immediately" or "page gets clicks but low engagement" | EA — Expectation Architecture | The snippet sets an expectation the page doesn't resolve |
| "Page ranks but doesn't convert" and no obvious technical issue | EA then HI | Expectation mismatch + anxiety not addressed |
| "We want to target the anxiety, not the keyword" | HI — Hidden Intent | Explicit anxiety-first framing request |
| "Users are confused or overwhelmed by the topic" | HI | Cognitive overload is a hidden intent signal |
| "Our content looks thin or untrustworthy compared to competitors" | CS — Costly Signal | Trust gap is the problem |
| "We're a new site or brand with no authority signals" | CS | Costly signals compensate for low domain authority |
| "This page has been technically correct for months and still doesn't move" | LPD — Logic-Proof Detector | Persistent logical failure → non-logical intervention |
| "We want to test whether a small change makes a big difference" | TA — Trivia Amplifier | Specific to testing butterfly effects |
| "We want to find demand that isn't in the keyword tools" | AW — Anti-Waggle-Dance | Explicit non-tool signal sourcing |
| "We're not the market leader and need to reframe being second" | AP — Adaptive Preference | Second-best position reframing |
| "Our free/limited tier makes users feel resentful" | AP | Free tier resentment is the adaptive preference problem |
| "We get impressions from AI Overviews but no click credit" | EA + CS | Visibility without click attribution needs extraction-first design |
| Outlier brief with no specific problem stated | HI first (most broadly applicable) | Hidden intent is the most commonly missing element |

---

## Routing decisions

### Routing decision EA

Call `alchemy/expectation-architecture.md §Entrypoint` with:
- Page URL or topic
- Primary referral pathway (organic SERP / social / email / referral)
- Current meta description and title tag text
- Engagement data if available (bounce rate, scroll depth, time on page)

EA returns: expectation gap analysis and specific corrections to snippet and opening sequence.

### Routing decision HI

Call `alchemy/hidden-intent.md §Entrypoint` with:
- Page URL or topic
- Primary query
- Any Reddit or review corpus signals available (from anti-waggle-dance if already run)

HI returns: hidden intent classification and specific framing instructions for opening sequence, H1, and first subheading.

### Routing decision CS

Call `alchemy/costly-signal.md §Entrypoint` with:
- Page URL
- Current trust signals present (if known)
- Competitive context (what trust signals do the top-3 competitors show?)

CS returns: trust signal audit and specific upgrade recommendations.

### Routing decision TA

Call `alchemy/trivia-amplifier.md §Entrypoint` with:
- Page URL
- Current conversion or engagement metrics
- Any candidate trivial interventions already identified

TA returns: five candidate interventions with hypothesis format for each.

### Routing decision LPD

Call `alchemy/logic-proof-detector.md §Entrypoint` with:
- Page URL
- History of logical interventions already run (from memory.md)
- Current performance data

LPD returns: escalation round status and (if Round 4) a non-logical intervention type recommendation.

### Routing decision AW

Call `alchemy/anti-waggle-dance.md §Entrypoint` with:
- Topic or domain
- Standard tool findings if already run

AW returns: non-tool signal report with confidence-tiered discoveries.

### Routing decision AP

Call `alchemy/adaptive-preference.md §Entrypoint` with:
- The "second-best" situation being reframed (free tier / low ranking / new site / non-leader brand)
- Current page or UX design for the second-best position
- What the "best" position offers that this position currently lacks

AP returns: reframing strategy and specific content/design instructions for adaptive preference formation.

---

## Protocol output and return

After the selected protocol runs:

1. If this was called by `outlier-bee.md §Protocol selection`: return the selected protocol name and its key operating rules to `outlier-bee.md §Brief construction` for embedding in the outlier brief.

2. If this was called directly by `SKILL.md`: present the protocol output to the user and log to memory.

3. Always log the protocol selection to `memory/memory.md §Protocol History.Alchemy Applications` with:
   - Date
   - Site/page
   - Protocol selected
   - Context (why this protocol was selected)
   - Hypothesis generated (if applicable)

---

## Link contracts

- `alchemy/expectation-architecture.md §Entrypoint` — receives routing context (this file calls EA)
- `alchemy/hidden-intent.md §Entrypoint` — receives routing context (this file calls HI)
- `alchemy/costly-signal.md §Entrypoint` — receives routing context (this file calls CS)
- `alchemy/trivia-amplifier.md §Entrypoint` — receives routing context (this file calls TA)
- `alchemy/logic-proof-detector.md §Entrypoint` — receives routing context (this file calls LPD)
- `alchemy/anti-waggle-dance.md §Entrypoint` — receives routing context (this file calls AW)
- `alchemy/adaptive-preference.md §Entrypoint` — receives routing context (this file calls AP)
- `roles/outlier-bee.md §Brief construction` — receives selected protocol from §Protocol output (this file calls back to outlier-bee)
- `memory/memory.md §Protocol History.Alchemy Applications` — receives selection log entry (this file writes to memory)
- `SKILL.md` — receives routing from master; all protocol outputs return through here to user if SKILL-initiated
