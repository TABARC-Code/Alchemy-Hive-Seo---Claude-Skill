---
id: expectation-architecture
version: "1.0"
layer: alchemy

links:
  calls:
    - id: memory
      reason: "logs EA audit results"
      contract: "memory §Sites.[domain].Expectation Architecture Audit receives outcome"
  called_by:
    - id: alchemy-router
      reason: "routes here when snippet-to-page gap is identified"
      contract: "§Entrypoint receives context from alchemy-router §Routing decision EA"
    - id: follower-bee
      reason: "applies EA at every follower setup and refresh"
      contract: "§Entrypoint receives follower URL and referral pathway from follower-bee §EA application"
  chain_down:
    - id: memory
      relationship: "EA outcomes log to memory"
  chain_up:
    - id: alchemy-router
      relationship: "receives routing from alchemy-router"
    - id: follower-bee
      relationship: "receives follower context from follower-bee"
  lateral:
    - id: hidden-intent
      relationship: "EA manages the pre-click promise; HI manages the on-page anxiety response — they are sequential, not alternative"
---

# Expectation Architecture — Pre-Click to On-Page Gap Management

Every page is experienced relative to the expectation set by whatever delivered the click. SERP snippet, social preview, ad copy, referral anchor text — these are expectation-setting devices. If they promise transformation and deliver information, the page fails not because it is bad but because the gap between promise and reality generates friction.

This protocol audits and closes that gap.

---

## Entrypoint

Receives: page URL, primary referral pathway, current title tag and meta description, engagement data if available.

---

## Step 1 — Map referral pathways

Identify the top three pathways that deliver traffic to this page:

| Pathway type | Expectation it creates |
|---|---|
| Organic SERP (title + meta description) | Set by the exact words in the snippet — check what the snippet currently says |
| Social share | Set by the OG title and OG description tags |
| Email link | Set by the email subject line and surrounding context |
| Referral from another page | Set by the anchor text used to link here |
| Paid search | Set by the ad headline and description |

For each active pathway: write down the exact expectation created in one sentence. "A user clicking this expects to [verb] [noun] in order to [outcome]."

---

## Step 2 — Audit the opening sequence

Read the first three visible elements of the page as a new user would see them within 5 seconds:

1. H1 or page title
2. Subheading or standfirst (if present)
3. First paragraph

Ask: does the opening sequence confirm the expectation stated in Step 1?

**Confirmation** = the user reads the opening and thinks "yes, this is exactly what I was looking for."  
**Betrayal** = the user reads the opening and thinks "this isn't quite what I expected" and either scrolls aggressively or bounces.

---

## Step 3 — Classify the gap

| Gap type | Description | Fix |
|---|---|---|
| Scope gap | Snippet promises a narrower answer than the page delivers | Narrow the snippet to match the page's opening focus |
| Depth gap | Snippet promises depth; page opens with basic context | Move the depth signal to the opening paragraph |
| Format gap | Snippet implies a format (list, steps, tool) that the page doesn't start with | Restructure the opening to match the implied format |
| Emotional register gap | Snippet is confident and directive; page opens hesitantly (or vice versa) | Align the opening tone to the snippet's register |
| Outcome gap | Snippet promises a result; page opens with background | State the result first, background second |

---

## Step 4 — Corrections

Apply fixes in this priority order:

1. **Snippet correction first** — if the snippet is overpromising, correct it. A more accurate snippet that sets achievable expectations will reduce bounce even if the click volume drops slightly.

2. **Opening sequence correction second** — if the page opens poorly relative to the expectation, rewrite the first paragraph. Lead with the resolution, not the context.

3. **Format alignment third** — if the snippet implies a format (steps, list, table) and the page opens with prose, add the format to the top of the page before the prose explanation.

---

## Output format

```
EA AUDIT RESULT
Page: [URL]
Date: [DATE]

Primary referral pathway: [pathway type]
Expectation set: "[exact expectation in one sentence]"
Opening sequence: [H1 / subhead / first para — 50-word summary]
Gap identified: [gap type or "none"]
Gap severity: [none / minor / moderate / significant]

Corrections required:
  Snippet: [change needed or "none"]
  Opening sequence: [change needed or "none"]
  Format: [change needed or "none"]

After correction — new expectation alignment: [confirm or pending]
```

Log to `memory/memory.md §Sites.[domain].Expectation Architecture Audit`.

---

## Link contracts

- `memory/memory.md §Sites.[domain].Expectation Architecture Audit` — receives outcome (this file writes to memory)
- `alchemy/alchemy-router.md §Routing decision EA` — supplies context (alchemy-router calls this file)
- `roles/follower-bee.md §EA application` — supplies follower URL and referral pathway (follower-bee calls this file)
- `alchemy/hidden-intent.md` — lateral: EA manages pre-click; HI manages on-page anxiety; sequential when both needed
