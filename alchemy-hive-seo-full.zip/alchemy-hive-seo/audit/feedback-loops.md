---
id: feedback-loops
version: "1.0"
layer: audit

links:
  calls:
    - id: scout-bee
      reason: "triggers 90-day review; sends graduation or retirement signal"
      contract: "scout-bee §90-day review procedure receives review trigger from §Scout 90-day review"
    - id: follower-bee
      reason: "triggers refresh cycle when SERP drift or schedule deadline detected"
      contract: "follower-bee §Refresh cycle receives drift signal from §Follower drift detection"
    - id: memory-bee
      reason: "triggers 6-month memory asset audit"
      contract: "memory-bee §Audit procedure receives review signal from §Memory audit trigger"
    - id: outlier-bee
      reason: "triggers 120-day outlier review; sends graduation or retirement signal"
      contract: "outlier-bee §120-day review procedure receives review trigger from §Outlier 120-day review"
    - id: memory
      reason: "reads pending review calendar; writes graduation log, resolution entries"
      contract: "memory §Pending Reviews read at session; §Protocol History.Graduation Log written on role transitions"
    - id: trivia-amplifier
      reason: "receives win notification to propagate to similar pages"
      contract: "trivia-amplifier §Policy promotion receives policy propagation trigger from §Trivia result propagation"

  called_by:
    - id: SKILL
      reason: "routes review and graduation requests here"
      contract: "§Entrypoint receives routing from SKILL.md"
    - id: scout-bee
      reason: "calls feedback-loops when a scout reaches its review trigger"
      contract: "§Scout 90-day review receives scout URL from scout-bee §Review trigger"
    - id: outlier-bee
      reason: "calls feedback-loops when an outlier reaches its review trigger"
      contract: "§Outlier 120-day review receives outlier URL from outlier-bee"
    - id: trivia-amplifier
      reason: "calls feedback-loops on a winning experiment"
      contract: "§Trivia result propagation receives win notification from trivia-amplifier §Policy promotion"

  chain_down:
    - id: scout-bee
      relationship: "graduation signals chain to scout-bee, which chains to follower-bee"
    - id: follower-bee
      relationship: "drift signals chain to follower-bee refresh"
    - id: memory-bee
      relationship: "schedule signals chain to memory-bee audit"
    - id: outlier-bee
      relationship: "graduation signals chain to outlier-bee, which chains to follower-bee"
    - id: memory
      relationship: "all transitions log to memory"
  chain_up:
    - id: SKILL
      relationship: "receives routing from master"
    - id: scout-bee
      relationship: "receives review trigger from scout-bee"
    - id: outlier-bee
      relationship: "receives review trigger from outlier-bee"

  lateral:
    - id: memory
      relationship: "bidirectional: reads pending review calendar to find due items; writes graduation and resolution log entries"
    - id: waggle-dance
      relationship: "scout failures feed back to waggle-dance negative feedback loop"
    - id: alchemy-router
      relationship: "outlier graduation outcomes update alchemy-router protocol selection heuristics"
---

# Feedback Loops — Propagation Rules Between Skills

Every time something happens in the system — a scout validates, an outlier fails, a trivia test wins, a follower drifts — that event must propagate correctly through the chain. This file governs all propagation rules.

It is the system's nervous system. It reads the pending review calendar from memory, fires review triggers, and manages the structured contracts for every role transition.

---

## Entrypoint

Called by `SKILL.md` for explicit review requests, or called by `scout-bee.md`, `outlier-bee.md`, and `trivia-amplifier.md` when a time-bounded event reaches its deadline.

At every session start: `SKILL.md` reads `memory/memory.md §Pending Reviews`. If any item is overdue (date < today), it routes here immediately before handling the user's primary request.

---

## Scout 90-day review

### Trigger
Received from `scout-bee.md §Review trigger` or from `SKILL.md` detecting an overdue pending review.

### Procedure

1. Load the scout's brief from `memory/memory.md §Sites.[domain].Scout Log` (the URL, hypothesis, hidden intent classification, success signals, and failure signals)

2. Check each success signal:
   - Was it indexed within 14 days? (Check GSC or manual URL inspection)
   - Did it receive any organic impressions? (GSC impressions for the URL)
   - CTR relative to impressions at 90 days vs. site average?
   - Was it cited in an AI Overview?
   - Did it generate a backlink from a new referring domain?
   - Did it occupy a SERP format the site hadn't previously held?

3. Apply the graduation decision matrix from `roles/scout-bee.md §Graduation criteria`:
   - 2+ success signals fired → Graduate
   - 0 success signals, zero impressions, not indexed → Retire
   - Impressions but no clicks → Escalate to Outlier consideration
   - Partial signals, ambiguous → Extend by 30 days (once only)

### Graduation chain (Scout → Follower)

If graduating:

```
feedback-loops.md
  → scout-bee.md §Graduation procedure (confirm graduation conditions met)
    → follower-bee.md §Entrypoint (pass validated data: URL, hypothesis confirmed, performance baseline)
      → follower-bee runs full initial setup procedure
        → memory/memory.md §Protocol History.Graduation Log (write transition entry)
        → memory/memory.md §Sites.[domain].Scout Log (update status: Graduated)
        → memory/memory.md §Sites.[domain].Follower Log (add new follower entry)
        → memory/memory.md §Pending Reviews (remove 90-day scout review; add follower drift check in 3 months)
```

Every step in this chain writes to memory. The graduation is not complete until all five memory writes are confirmed.

### Retirement chain (Scout → Retired)

If retiring:

```
feedback-loops.md
  → scout-bee.md (confirm retirement conditions met; name failure reason)
    → memory/memory.md §Sites.[domain].Scout Log (update status: Retired; record failure reason)
    → memory/memory.md §Pending Reviews (remove review entry)
    → intelligence/waggle-dance.md §Negative feedback loop (send failure reason — updates waggle-dance procedure)
```

The failure reason from `scout-bee.md §Retirement criteria` must be one of the named types. "It just didn't work" is not a named failure reason and is not accepted.

### Escalation chain (Scout → Outlier)

If the scout has impressions but no clicks consistently:

```
feedback-loops.md
  → outlier-bee.md §Entrypoint (pass escalation data: URL, GSC impressions-to-clicks ratio, hidden intent classification)
    → outlier-bee runs brief construction with zero-click-first strategy
      → memory/memory.md §Sites.[domain].Scout Log (update status: Escalated to Outlier)
      → memory/memory.md §Sites.[domain].Outlier Log (add new outlier entry)
      → memory/memory.md §Pending Reviews (remove 90-day scout review; add 120-day outlier review)
```

---

## Outlier 120-day review

### Trigger
Received from `outlier-bee.md` or from `SKILL.md` detecting overdue pending review.

### Procedure

1. Load the outlier's brief from `memory/memory.md §Sites.[domain].Outlier Log` (URL, alchemy protocol, hypothesis, success signals, failure signals)

2. Check each success and failure signal as specified in the brief

3. Apply the decision matrix from `roles/outlier-bee.md §120-day review procedure`

### Graduation chain (Outlier → Follower)

If graduating:

```
feedback-loops.md
  → outlier-bee.md §Graduation to Follower (confirm graduation conditions)
    → follower-bee.md §Entrypoint (pass URL, validated hypothesis, alchemy protocol to retain, performance data)
      → follower-bee runs full initial setup procedure with protocol context embedded
        → memory/memory.md §Protocol History.Graduation Log (write transition with protocol that worked)
        → memory/memory.md §Protocol History.Alchemy Applications (update outcome for this protocol use)
        → memory/memory.md §Sites.[domain].Outlier Log (update status: Graduated)
        → memory/memory.md §Sites.[domain].Follower Log (add new follower entry)
        → memory/memory.md §Pending Reviews (remove 120-day outlier review; add follower drift check)
        → alchemy-router.md (lateral write: update protocol selection heuristics — this protocol worked in this context)
```

### Retirement chain (Outlier → Retired)

If retiring:

```
feedback-loops.md
  → outlier-bee.md §Retirement procedure (confirm retirement; name failure reason from named list)
    → memory/memory.md §Sites.[domain].Outlier Log (update status: Retired; failure reason recorded)
    → memory/memory.md §Pending Reviews (remove review entry)
    → alchemy/[protocol that was applied].md (lateral write: add negative feedback note — this context did not validate this protocol)
    → alchemy-router.md (lateral write: update selection heuristics — reduce confidence for this protocol in this context type)
```

The negative feedback write to the alchemy protocol file is mandatory. Protocols must improve from failures, not just from wins.

---

## Follower drift detection

### Trigger
Scheduled from `memory/memory.md §Pending Reviews`. A follower drift check is set 3 months from the follower's last refresh.

### Procedure

1. Check the follower's current average position against its baseline from the last refresh (from `memory/memory.md §Sites.[domain].Follower Log`)

2. Check whether the SERP for the primary query has changed format, dominant page type, or dominant angle

3. If average position has dropped 5+ positions OR SERP has materially changed:

```
feedback-loops.md
  → follower-bee.md §Refresh cycle (trigger with: SERP drift detected, current position, SERP change description)
    → follower-bee runs full refresh procedure
      → memory/memory.md §Sites.[domain].Follower Log (log refresh event)
      → memory/memory.md §Pending Reviews (reset drift check clock to 3 months from today)
```

4. If position is stable and SERP unchanged:

```
feedback-loops.md
  → memory/memory.md §Pending Reviews (reset drift check clock to 3 months from today; note stable)
```

---

## Memory audit trigger

### Trigger
6-month schedule from `memory/memory.md §Pending Reviews`.

### Procedure

```
feedback-loops.md
  → memory-bee.md §Audit procedure (trigger with: URL, last audit date, current link equity status if available)
    → memory-bee runs full 6-month audit (refresh / consolidate / retire decision)
      → memory/memory.md §Sites.[domain].Memory Asset Log (log audit outcome)
      → memory/memory.md §Pending Reviews (reset 6-month audit clock or remove if retired)
```

If memory asset is consolidated into a Follower:

```
memory-bee.md
  → follower-bee.md §Entrypoint (pass consolidated content and redirect confirmation)
    → memory/memory.md §Sites.[domain].Memory Asset Log (update status: Consolidated)
    → memory/memory.md §Sites.[domain].Follower Log (note that equity from [URL] was merged in)
```

---

## Trivia result propagation

### Trigger
Called by `trivia-amplifier.md §Policy promotion` when an experiment wins (medium-to-high confidence improvement).

### Procedure

```
trivia-amplifier.md
  → feedback-loops.md §Trivia result propagation (win: intervention type + magnitude + pages to update)
    → For each similar page in the list:
        follower-bee.md §Entrypoint (apply winning intervention — not a test, this is policy)
          → memory/memory.md §Protocol History.Trivia Amplifier Log (update policy decision and pages affected)
```

Similar pages are identified by:
- Same role (Follower)
- Same intent category
- Same type of element being changed (e.g., if the winning intervention was opening paragraph length, apply to all Followers where opening paragraph length was over 5 sentences)

---

## Logic-proof resolution

### Trigger
Called by `logic-proof-detector.md` when a Round 4 non-logical intervention has completed its 120-day observation window.

### Procedure

1. Load the intervention from `memory/memory.md §Protocol History.Logic-Proof Escalation Log`

2. Compare performance before and after the non-logical intervention

3. If improved:

```
feedback-loops.md
  → logic-proof-detector.md (confirm resolution)
    → memory/memory.md §Protocol History.Logic-Proof Escalation Log (update: resolved, intervention type that worked)
    → If the page now performs as a Follower: brief follower-bee.md to take it over with the non-logical framing retained
```

4. If not improved after 120 days:

```
feedback-loops.md
  → memory/memory.md §Protocol History.Logic-Proof Escalation Log (update: unresolved after Round 4)
  → Flag to user: this page has resisted four intervention rounds including a non-logical one — consider retiring and replacing with a fundamentally different approach
```

---

## Bidirectional chain integrity check

At every propagation event, confirm the bidirectional contract has been honoured:

**Rule:** If A transitions to B (e.g., Scout graduates to Follower), then:
1. A's record in memory must reflect the transition (status updated)
2. B's record in memory must acknowledge the source (where this Follower came from)
3. Any skills that called A must be notified that A's role has changed
4. Any skills that will now call B must receive the relevant context from A

**Chain integrity verification:**

```
For every graduation/retirement/escalation:
  ✓ Source role status updated in memory
  ✓ Destination role briefed with source context
  ✓ Pending review calendar updated (old entry removed, new entry added)
  ✓ At least one alchemy protocol file updated with outcome (win or loss)
  ✓ Graduation log entry complete (from/to/date/signal/notes)
```

If any of these five checks is missing, the propagation is incomplete. Note the gap in memory and complete it before the next session.

---

## Reverse chain notation

Not all information flows downstream. Some critical reverse flows:

| Downstream event | Reverse flow to | Content of reverse signal |
|---|---|---|
| Scout retirement (hidden-intent-wrong) | hidden-intent.md | "This intent classification was wrong in this context: [context]. Review taxonomy." |
| Scout retirement (format-mismatch) | waggle-dance.md | "SERP scan missed format shift for this query pattern. Add time-comparison check." |
| Outlier graduation | alchemy-router.md | "This protocol worked in this context. Increase selection confidence for similar contexts." |
| Outlier retirement (protocol-wrong) | [protocol file] + alchemy-router.md | "This protocol failed in this context. Add to context-exclusion list." |
| Trivia win propagated | trivia-amplifier.md | "This intervention type is now policy for this page class. Update log." |
| Follower CCT fail at refresh | counterfactual-test.md | "This type of content decays in this SERP environment. Note pattern." |
| Logic-proof resolved | logic-proof-detector.md | "Round 4 intervention type [X] resolved [context]. Update intervention recommendation list." |

Each reverse flow is a named event, not a vague feedback. The signal content must be specific.

---

## Link contracts

- `roles/scout-bee.md §90-day review procedure` — receives review trigger (this file calls scout-bee)
- `roles/scout-bee.md §Graduation procedure` — receives graduation confirmation (this file calls scout-bee)
- `roles/follower-bee.md §Entrypoint` — receives graduating scout/outlier data (this file chains to follower-bee via graduation)
- `roles/follower-bee.md §Refresh cycle` — receives drift signal (this file calls follower-bee)
- `roles/memory-bee.md §Audit procedure` — receives 6-month review signal (this file calls memory-bee)
- `roles/outlier-bee.md §120-day review procedure` — receives review trigger (this file calls outlier-bee)
- `memory/memory.md §Pending Reviews` — read at session start; written after every transition (this file reads and writes memory)
- `memory/memory.md §Protocol History.Graduation Log` — receives graduation entries (this file writes to memory)
- `alchemy/trivia-amplifier.md §Policy promotion` — receives win notification (trivia-amplifier calls this file; this file calls back with page list)
- `alchemy/alchemy-router.md` — receives lateral updates on protocol win/loss outcomes (this file writes to alchemy-router after outlier transitions)
- `alchemy/[protocol].md` — receives negative feedback on outlier retirement with protocol-wrong failure reason (this file writes to protocol files)
- `intelligence/waggle-dance.md §Negative feedback loop` — receives scout failure reasons (this file calls waggle-dance on scout retirement)
- `SKILL.md` — receives routing from master (SKILL calls this file)
