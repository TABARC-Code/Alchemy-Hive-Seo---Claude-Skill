---
id: site-audit
version: "1.0"
layer: audit

links:
  calls:
    - id: colony-core
      reason: "runs C1–C10 checklist on every indexed page"
      contract: "colony-core §Checklist receives page URL list from §Colony Core Checklist"
    - id: waggle-dance
      reason: "runs anti-waggle scan of the site's topic space during audit"
      contract: "waggle-dance §Entrypoint receives site topic space from §Anti-waggle scan"
    - id: counterfactual-test
      reason: "runs CCT on all existing Follower-candidate pages"
      contract: "counterfactual-test §Entrypoint receives follower candidates from §Content gate"
    - id: scout-bee
      reason: "assigns Scout role to experimental/speculative pages found during audit"
      contract: "scout-bee §Entrypoint receives experimental page assignments from §Role assignment"
    - id: follower-bee
      reason: "assigns Follower role to proven-intent pages found during audit"
      contract: "follower-bee §Entrypoint receives proven-intent pages from §Role assignment"
    - id: memory-bee
      reason: "assigns Memory role to legacy equity pages found during audit"
      contract: "memory-bee §Entrypoint receives legacy page assignments from §Role assignment"
    - id: outlier-bee
      reason: "assigns Outlier role to experimental-format pages found during audit"
      contract: "outlier-bee §Entrypoint receives experimental format pages from §Role assignment"
    - id: memory
      reason: "writes complete audit output to memory"
      contract: "memory §Sites.[domain] receives full audit results, page role register, and pending reviews"

  called_by:
    - id: SKILL
      reason: "routes audit requests here"
      contract: "§Entrypoint receives site URL and context from SKILL.md"

  chain_down:
    - id: colony-core
      relationship: "audit triggers colony-core checklist on all pages"
    - id: waggle-dance
      relationship: "audit triggers waggle-dance scan"
    - id: counterfactual-test
      relationship: "audit triggers CCT on follower candidates"
    - id: "[role skills]"
      relationship: "role assignments trigger role skill onboarding procedures"
    - id: memory
      relationship: "audit writes to memory"
  chain_up:
    - id: SKILL
      relationship: "receives routing from master"

  lateral:
    - id: feedback-loops
      relationship: "audit sets up the pending review calendar used by feedback-loops"
    - id: measurement-architecture
      relationship: "audit baseline measurements feed measurement-architecture §Baseline establishment"
---

# Site Audit — Full Site Audit Procedure

The site audit is the system's initialisation event for a new site, and its periodic health check for an existing one. It assigns every page a role, runs the colony-core checklist, establishes the waggle-dance signal landscape, and populates memory with the complete site state.

Run this when: a new site is brought into the system, or every 6 months for existing sites, or after a significant algorithm update.

---

## Entrypoint

Receives from `SKILL.md`:
- Site domain (required)
- Crawl data or page list (required — if not provided, ask user to supply a sitemap URL or GSC page list)
- Google Search Console access (if available — significantly improves audit quality)
- Current business context (what is the site trying to achieve?)

---

## Pre-audit checks

Before starting the main audit procedure:

1. Check `memory/memory.md §Sites.[domain]` — has this site been audited before? If yes, load the existing page role register and compare against current page list to identify new pages and retired pages.

2. Confirm the page list is reasonably complete. A sitemap XML is the fastest source. GSC's "Pages" report is the most accurate for indexed pages. If neither is available, note the limitation in the audit report.

3. Note the current date in the report — all review deadlines are calculated from the audit date.

---

## Phase 1 — Page inventory and classification

For every indexed page in the provided list:

### Initial classification criteria

Assign each page a provisional role using these criteria. Confirm or revise after the colony-core checklist.

| Evidence | Provisional role |
|---|---|
| Page has 3+ referring external domains OR has held a top-20 position for 12+ months | Memory |
| Page targets a query with confirmed search demand AND matches the SERP intent format | Follower |
| Page targets a low-volume or unmeasured query, or uses an unconventional format | Scout |
| Page uses a deliberately non-standard strategy, format, or framing | Outlier |
| Page has no clear strategic purpose | Unclassified — flag for decision |
| Page is clearly administrative (contact, privacy policy, legal) | Infrastructure — excluded from role system |

### Record in page role register

For every page, record:
- URL
- Provisional role
- Primary query targeted (best estimate)
- Current ranking position if available (from GSC or manual check)
- Inbound external links count if available
- Last modified date if available

---

## Phase 2 — Colony Core checklist

Call `core/colony-core.md §Checklist` for every page assigned a strategic role (Scout, Follower, Memory, Outlier). Do not run checklist on Infrastructure pages.

For sites with large page counts (100+ strategic pages): prioritise in this order:
1. All Memory pages (protect existing equity)
2. All current Followers (confirm production pages are technically sound)
3. Scouts and Outliers (lower priority but still required before next deployment)

Record all pass/fail results in the audit report.

**Critical fails requiring immediate action before proceeding:**
- Any Follower or Memory page with C1 fail (not reachable)
- Any Follower or Memory page with C2 fail (canonical conflict)
- Any Follower or Memory page with C3 fail (accidental noindex)

These are equity-destroying failures. Flag them prominently in the report.

---

## Phase 3 — Content gate (Counterfactual Content Test)

Run `intelligence/counterfactual-test.md` on:
- All existing Follower candidates
- Any Memory pages that haven't been tested in the past 12 months

Record CCT pass/fail for each. Pages that fail CCT are flagged for content upgrade before the next publishing cycle.

Do not immediately retire pages that fail CCT during an audit — instead, schedule a content upgrade with a 60-day deadline and note in `memory/memory.md §Pending Reviews`.

---

## Phase 4 — Anti-waggle scan

Call `intelligence/waggle-dance.md §Entrypoint` with:
- The site's topic space (derived from Phase 1 page inventory)
- Any existing keyword coverage from Phase 1

Waggle-dance will run the standard tool scan and then call `alchemy/anti-waggle-dance.md`. The combined signal report identifies:
- Topics the site doesn't yet cover (Scout opportunities)
- Query patterns the site is missing (additional Follower briefs)
- Non-tool demand signals (Outlier candidates)

Log the signal report to `memory/memory.md §Protocol History.Waggle Dance Signals`.

---

## Phase 5 — Role assignments and onboarding

For pages with confirmed roles (post-checklist):

**Followers:** Brief `roles/follower-bee.md §Entrypoint` with the page URL and performance data. Follower-bee runs its initial setup procedure (intent match, HI, EA, CS, internal links, colony-core validation) and logs optimisation events to memory.

**Memory assets:** Brief `roles/memory-bee.md §Entrypoint` with the page URL, link equity status, and entity ownership assessment. Memory-bee runs its audit procedure and logs to memory.

**Scouts:** Confirm each Scout's existing brief parameters. If no brief exists (page was published without one), reconstruct it from available data and log to memory. Set 90-day review dates for any scouts already past their original review date.

**Outliers:** Confirm each Outlier's hypothesis. If no hypothesis exists, classify it as an Outlier and log it as "hypothesis pending" — it cannot be properly evaluated without one.

---

## Phase 6 — Pending review calendar

Based on Phase 5 role assignments, populate `memory/memory.md §Pending Reviews` with:

- All Scout 90-day reviews (from Scout deployment dates)
- All Outlier 120-day reviews (from Outlier deployment dates)
- All Memory 6-month audits (from Memory assignment dates)
- All Follower SERP-drift checks (schedule 3 months from audit date)
- All CCT upgrade deadlines (60 days for pages that failed Phase 3)

---

## Audit report output

Produce the completed audit report using `templates/audit-report.md` format. The report must include:

1. Executive summary (5–10 sentences: site's current colony health, critical fails, immediate actions, top opportunities)
2. Page role register (all pages with roles, current status, any immediate action needed)
3. Colony-core checklist summary (pass rates per rule, critical failures listed)
4. CCT results (pages passing and failing, upgrade schedule)
5. Anti-waggle signal report (top Scout and Outlier opportunities from Phase 4)
6. Pending review calendar
7. Recommended priority actions (no more than 5, ranked by expected impact)

---

## Memory write

At audit completion, write to `memory/memory.md §Sites.[domain]`:
- Full page role register (replacing any previous version)
- Audit date
- Colony health summary
- All pending review dates
- All critical action items

Confirm the memory write before closing the audit session.

---

## Link contracts

- `core/colony-core.md §Checklist` — receives page URL list from §Colony Core Checklist (this file calls colony-core)
- `intelligence/waggle-dance.md §Entrypoint` — receives site topic space from §Anti-waggle scan (this file calls waggle-dance)
- `intelligence/counterfactual-test.md §Entrypoint` — receives follower candidates from §Content gate (this file calls CCT)
- `roles/scout-bee.md §Entrypoint` — receives experimental page assignments from §Role assignment (this file calls scout-bee)
- `roles/follower-bee.md §Entrypoint` — receives proven-intent pages from §Role assignment (this file calls follower-bee)
- `roles/memory-bee.md §Entrypoint` — receives legacy page assignments from §Role assignment (this file calls memory-bee)
- `roles/outlier-bee.md §Entrypoint` — receives experimental format pages from §Role assignment (this file calls outlier-bee)
- `memory/memory.md §Sites.[domain]` — receives full audit output (this file writes to memory)
- `memory/memory.md §Pending Reviews` — receives review calendar (this file writes pending reviews to memory)
- `SKILL.md` — receives routing from master (SKILL calls this file)
- `audit/feedback-loops.md` — lateral: audit initialises the review calendar; feedback-loops operates on it
