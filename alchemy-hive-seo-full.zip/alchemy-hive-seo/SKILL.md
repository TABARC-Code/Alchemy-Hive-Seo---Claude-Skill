---
name: alchemy-hive-seo
description: >
  Alchemy Hive SEO Skill. Master SEO strategy system fusing Sutherland Alchemy model (controlled
  irrationality, costly signalling), the Bee Colony model (Scout, Follower, Memory, Outlier page
  roles), and Outlier SEO practice (hidden intent, entity-first, anti-fragility). Persistent memory
  across sessions. Technical implementation by the TABARC-Code programmer persona.

  Use when asked about: SEO audits, site audits, keyword research, content strategy, page roles,
  search intent, waggle dance research, alchemy protocols, scout briefs, follower optimisation,
  memory asset management, outlier pages, counterfactual testing, hidden intent, costly signals,
  trivia amplifier, logic-proof pages, adaptive preference, technical SEO implementation, structured
  data, Core Web Vitals, robots.txt, canonical tags, or any organic search strategy. Trigger for:
  why is this page not ranking, what content should I create, how do I improve this page, audit my
  site, or any Google search visibility request. If in doubt, use this skill.
---

# ALCHEMY-HIVE SEO SKILL — Master Router

Entry point for the entire system. Every request comes in here, gets classified, and routes to the right skill or skill chain.

---

## Sequential thinking protocol

Before routing any request, run this sequence in order. Do not skip steps.

**Step 1 — Session load:** Read `memory/memory.md`. Load active experiments, page roles for the site in question, pending 90/120-day reviews, and any logic-proof escalations in progress.

**Step 2 — Date check:** Note the current date relative to any review deadlines in memory. If a review is overdue (>5 days past deadline), flag it in the response before handling the new request.

**Step 3 — Classification:** Read the user's request and match it to the routing table below. Apply the first match.

**Step 4 — Chain selection:** If the request matches a multi-skill chain, load the chain definition before dispatching. Do not improvise chain order.

**Step 5 — Dispatch:** Route to the appropriate skill. Pass all required context. Do not strip context between skill handoffs.

**Step 6 — Session close:** After every session involving a write operation, confirm memory.md has been updated. Log all activated skills, all new experiments, and all next review dates.

---

## Request classification

| Pattern in request | Route to | Also trigger |
|---|---|---|
| "audit [site/url/domain]" | `audit/site-audit.md` | `memory/memory.md` write |
| "scout [topic/query/url]" | `intelligence/waggle-dance.md` then `roles/scout-bee.md` | `memory/memory.md` write |
| "follower [page/topic]" | `roles/follower-bee.md` | `memory/memory.md` write |
| "memory asset [page/url]" | `roles/memory-bee.md` | `memory/memory.md` write |
| "outlier [topic]" | `alchemy/alchemy-router.md` then `roles/outlier-bee.md` | `memory/memory.md` write |
| "waggle dance [topic]" | `intelligence/waggle-dance.md` then `alchemy/anti-waggle-dance.md` | — |
| "alchemy [protocol-name]" | `alchemy/alchemy-router.md` | `memory/memory.md` write |
| "counterfactual [page/idea]" | `intelligence/counterfactual-test.md` | — |
| "trivia [page/url]" | `alchemy/trivia-amplifier.md` | `memory/memory.md` write |
| "logic-proof [page/url]" | `alchemy/logic-proof-detector.md` | `memory/memory.md` write |
| "review [90-day/120-day]" | `audit/feedback-loops.md` | `memory/memory.md` write |
| "update memory" | `memory/memory.md` directly | — |
| "measure [site/page]" | `core/measurement-architecture.md` | — |
| "implement [fix/code/schema]" | `agents/tabarc-code.md` | `memory/memory.md` write |
| "write code for [SEO fix]" | `agents/tabarc-code.md` | — |
| "structured data [page]" | `agents/tabarc-code.md` | — |
| "core web vitals fix" | `agents/tabarc-code.md` | — |
| "implementation queue" | `agents/tabarc-code.md` | `memory/memory.md` write |
| no clear pattern | Ask one clarifying question | — |

---

## Multi-skill chains

Some requests require sequential skill activation. The full chains:

**Full site audit:**
```
SKILL.md
  → memory/memory.md (read)
  → audit/site-audit.md
    → core/colony-core.md (checklist)
    → intelligence/counterfactual-test.md (per Follower page)
    → intelligence/waggle-dance.md (anti-waggle scan)
    → roles/[scout|follower|memory|outlier]-bee.md (role assignment)
  → memory/memory.md (write)
```

**New scout brief:**
```
SKILL.md
  → memory/memory.md (read — check no duplicate scout intent)
  → intelligence/waggle-dance.md (signal sourcing)
  → alchemy/anti-waggle-dance.md (non-tool signals)
  → intelligence/counterfactual-test.md (gate)
  → roles/scout-bee.md (brief)
  → memory/memory.md (write — log new scout)
```

**Outlier with alchemy protocol:**
```
SKILL.md
  → memory/memory.md (read)
  → alchemy/alchemy-router.md (protocol selection)
  → alchemy/[selected-protocol].md
  → roles/outlier-bee.md (brief with protocol embedded)
  → memory/memory.md (write — log outlier hypothesis)
```

**Scout graduation review:**
```
SKILL.md
  → memory/memory.md (read — find scouts at 90-day mark)
  → audit/feedback-loops.md (graduation logic)
  → roles/follower-bee.md (if graduating)
  → memory/memory.md (write — update role, log outcome)
```

---

## Bidirectional information flow

Every skill in this system declares explicit upstream and downstream contracts in its YAML frontmatter. Information flows are not one-directional. When skill A invokes skill B:

- B receives a defined input from A (downstream flow)
- B returns a defined output that modifies A's understanding or memory state (upstream flow)
- Both A and B declare the contract explicitly — the link is reciprocated or it does not exist

When a chain runs (A → B → C → D):

1. B acknowledges A in its output header
2. C acknowledges B in its output header
3. D writes the terminal state to `memory/memory.md` — not A, B, or C
4. If D's findings modify the validity of B's input, that reanalysis flows back up the chain before session close

This bidirectional enforcement is non-negotiable. Skill handoffs that strip context or break chain acknowledgement are treated as incomplete sessions.

---

## Cross-fertilisation between skills

The following lateral relationships exist across the system. These are productive tensions, not redundancies. Each skill learns from the others.

| Skill A | Skill B | Cross-fertilisation |
|---|---|---|
| `hidden-intent.md` | `expectation-architecture.md` | HI governs on-page anxiety; EA governs pre-click promise — they are sequential, not alternatives |
| `waggle-dance.md` | `anti-waggle-dance.md` | Standard tool gaps feed anti-waggle targets; anti-waggle finds seed new waggle-dance procedures |
| `scout-bee.md` | `outlier-bee.md` | Scout impressions-no-click patterns escalate to Outlier; Outlier findings reset scout hypotheses |
| `trivia-amplifier.md` | `hidden-intent.md` | TA failures frequently expose hidden intent mismatches — failed TA tests trigger HI reassessment |
| `memory-bee.md` | `scout-bee.md` | Memory assets with entity ownership seed new scout briefs in adjacent subtopics |
| `follower-bee.md` | `memory-bee.md` | Followers declining over 6+ months demote to Memory; Memory assets recovering promote back |
| `logic-proof-detector.md` | `adaptive-preference.md` | AP is Round 4 of LPD's non-logical escalation — the reframe strategy for stuck pages |
| `counterfactual-test.md` | `colony-core.md` | C8 (information gain) delegates its full test to CCT — two files, one outcome |

---

## Feedback loops — positive and negative

**Positive feedback (winning signals propagate forward):**

- A Trivia Amplifier win triggers `feedback-loops.md §Trivia result propagation` — the winning intervention becomes policy for similar pages across the site
- A Scout graduating to Follower carries its validated hypothesis into the Follower optimisation chain — the alchemy protocol that made it work is preserved
- Anti-waggle signals that generate successful Scouts update waggle-dance procedure heuristics — what worked outside the tools modifies how the tools are used next time

**Negative feedback (failure signals propagate back):**

- Scout failures return named failure reasons to `waggle-dance.md §Negative feedback loop`:
  - `no-demand` → increase scepticism about low-volume tool estimates
  - `format-mismatch` → add time-comparison check to SERP landscape scan
  - `hidden-intent-wrong` → cross-check PAA against Reddit before intent classification
- Outlier retirements with `protocol-wrong` write failure context back to the relevant alchemy protocol file — the next time that protocol is considered, the failure case is in scope
- Follower SERP drift detected by `feedback-loops.md` triggers a full refresh cycle — the drift is not silent, it forces a re-run of intent match, CCT, and colony-core

**Skill self-improvement loop:**

Every skill file carries a version number. When a feedback signal modifies a skill's procedure (positive or negative), increment the version in the YAML frontmatter and log the change reason in `memory/memory.md §Notes`. This creates an auditable improvement record. The system does not silently update — every change has a named cause.

---

## Skill map

| Layer | File | Function |
|---|---|---|
| Master | `SKILL.md` | Entry point, router, chain definitions |
| Persistent state | `memory/memory.md` | All experiments, roles, outcomes |
| Core | `core/colony-core.md` | Ten determinate invariants (C1–C10) |
| Core | `core/measurement-architecture.md` | Five-dimension measurement model |
| Role | `roles/scout-bee.md` | Discovery page role |
| Role | `roles/follower-bee.md` | Exploitation page role |
| Role | `roles/memory-bee.md` | Legacy asset role |
| Role | `roles/outlier-bee.md` | Controlled deviation role |
| Intelligence | `intelligence/waggle-dance.md` | Structured demand signal research |
| Intelligence | `intelligence/counterfactual-test.md` | Publishing gate — four-question test |
| Alchemy | `alchemy/alchemy-router.md` | Protocol selector |
| Alchemy | `alchemy/expectation-architecture.md` | Pre-click to on-page gap management |
| Alchemy | `alchemy/hidden-intent.md` | Anxiety-first content framing |
| Alchemy | `alchemy/costly-signal.md` | Trust signal investment strategy |
| Alchemy | `alchemy/trivia-amplifier.md` | Small high-leverage interventions |
| Alchemy | `alchemy/logic-proof-detector.md` | Non-logical escalation for stuck pages |
| Alchemy | `alchemy/adaptive-preference.md` | Second-best position reframing |
| Alchemy | `alchemy/anti-waggle-dance.md` | Demand signals outside the keyword tools |
| Audit | `audit/site-audit.md` | Full site audit procedure |
| Audit | `audit/feedback-loops.md` | Role transitions, graduation, propagation |
| Templates | `templates/` | Output schemas for briefs, reports, logs |

---

## Link contracts (outbound from this file)

- `memory/memory.md §Active Sessions` — receives session log from every SKILL.md routing event
- `audit/site-audit.md §Entrypoint` — receives routing with site URL and context
- `roles/scout-bee.md §Entrypoint` — receives routing with topic, hidden intent hypothesis, and any anti-waggle signals
- `roles/follower-bee.md §Entrypoint` — receives routing with page URL and current performance data
- `roles/memory-bee.md §Entrypoint` — receives routing with page URL and equity status
- `roles/outlier-bee.md §Entrypoint` — receives routing with alchemy protocol selection and hypothesis
- `intelligence/waggle-dance.md §Entrypoint` — receives routing with topic and signal source instructions
- `alchemy/alchemy-router.md §Entrypoint` — receives routing with context and protocol preference
- `audit/feedback-loops.md §Entrypoint` — receives routing with list of experiments due for review
- `intelligence/counterfactual-test.md §Entrypoint` — receives routing with page or topic to gate
- `alchemy/trivia-amplifier.md §Entrypoint` — receives routing with page URL and current metrics
- `alchemy/logic-proof-detector.md §Entrypoint` — receives routing with stuck page URL and intervention history
- `core/measurement-architecture.md §Entrypoint` — receives routing with site or page to measure

---

## TABARC-Code — Programmer persona

Technical implementation is handled by the **TABARC-Code** agent, defined in `agents/tabarc-code.md`.

TABARC-Code is called when:
- `colony-core.md` produces a C1–C6 technical fail requiring code output
- `follower-bee.md` produces EA, CS, or structured data requirements
- `site-audit.md` Phase 5 produces a technical action list
- The user requests implementation directly (code, schema, robots.txt, Core Web Vitals fixes, canonical tags, redirect chains)

TABARC-Code writes its implementation queue to `memory/memory.md §Sites.[domain].Audit History` with fix type, date, and before/after measurement targets.

**Stack behaviour:** TABARC-Code asks one question if the CMS or tech stack is unknown before producing code. Stack-agnostic output is usually wrong output.

Covered: redirect chains, canonical implementation, robots.txt, XML sitemaps, viewport meta, structured data (JSON-LD — Article, FAQPage, HowTo, BreadcrumbList), LCP/CLS/INP Core Web Vitals fixes, image optimisation, anchor text audit tooling.
