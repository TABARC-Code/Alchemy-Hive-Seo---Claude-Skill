---
id: measurement-architecture
version: "1.0"
layer: core

links:
  calls:
    - id: memory
      reason: "writes measurement snapshots to site record"
      contract: "memory §Sites.[domain] receives measurement snapshots"
  called_by:
    - id: SKILL
      reason: "routes measurement requests here"
      contract: "§Entrypoint receives routing from SKILL.md"
    - id: site-audit
      reason: "audit establishes baseline measurements in this framework"
      contract: "§Baseline establishment receives audit data from site-audit §Phase 6"
    - id: follower-bee
      reason: "follower success is tracked against Dimensions 1 and 2"
      contract: "§Dimension 1 and 2 receives follower performance data"
    - id: scout-bee
      reason: "scout success metrics are tracked in Dimension 4"
      contract: "§Dimension 4 receives scout signal data"
    - id: outlier-bee
      reason: "outlier success tracked via Dimension 4 and Dimension 1 brand recall"
      contract: "§Dimension 1 and 4 receives outlier performance data"
    - id: colony-core
      reason: "technical compliance feeds Dimension 1 visibility scores"
      contract: "§Dimension 1 receives technical compliance summary from colony-core"

  chain_down:
    - id: memory
      relationship: "measurement snapshots write to memory"
  chain_up:
    - id: site-audit
      relationship: "receives baseline from site audit"
    - id: SKILL
      relationship: "receives routing"

  lateral:
    - id: feedback-loops
      relationship: "measurement outcomes trigger feedback-loops when thresholds are breached"
---

# Measurement Architecture — Five-Dimension Model

Standard SEO measurement — rankings, traffic, conversions — captures about 40% of what matters in this system. ALCHEMY-HIVE requires five dimensions because many of the most important effects (brand recall, adaptive gain, anti-fragility) are invisible to a rankings dashboard.

---

## Entrypoint

Called by `SKILL.md` for measurement requests, or by role skills when tracking performance.

---

## Dimension 1 — Visibility

What it measures: whether the site can be found, in what contexts, and by what means.

Not just rankings and clicks. The full visibility picture.

| Metric | Source | Frequency |
|---|---|---|
| Average position for primary queries (Follower pages) | Google Search Console | Monthly |
| Impressions trend | GSC | Monthly |
| Organic click volume | GSC | Monthly |
| AI Overview citation count (pages cited, queries triggering citation) | Manual SERP check for key queries | Quarterly |
| Featured snippet occupancy | Manual check for target queries | Quarterly |
| Branded search volume trend | GSC — filter for brand name queries | Quarterly |
| Domain citation frequency in AI outputs | Sample check of key topic queries | Quarterly |

**Visibility score (0–10):**
- Positions 1–3 for primary Follower queries: +3
- Consistent impressions growth QoQ: +2
- At least one AI Overview citation: +2
- At least one featured snippet: +1
- Branded search volume growing: +2

---

## Dimension 2 — Cognitive Friction

What it measures: how hard the site is to use. Not a direct ranking factor — a diagnostic for user-experience problems that precede performance failure.

Treated as operational diagnostics, not ranking signals.

| Metric | Source | What it proxies |
|---|---|---|
| Bounce rate by entry page vs. site baseline | Analytics | Expectation mismatch or severe cognitive overload |
| Scroll depth on long-form pages | Analytics / heatmap | Whether users are engaging with the content or abandoning early |
| Time on page relative to content length | Analytics | Engagement vs. skimming vs. abandonment |
| Return visit rate | Analytics | Whether the site became a trusted reference or a one-time visit |
| Pages per session for organic landing | Analytics | Whether the internal link choreography is working |

**Cognitive Friction alert thresholds:**

| Alert | Threshold | Action |
|---|---|---|
| High bounce on a Follower page | >60% bounce on a page with >100 sessions/month | Trigger Expectation Architecture audit for that page |
| Low scroll depth | <30% of users reaching 50% of page scroll | Review opening sequence; apply Hidden Intent framing |
| Below-average time on page | <50% of what a human would need to read the content | Check for content quality issues; check intent match |
| Single-visit rate >85% | Users not returning | Review trust signals; consider whether the page is solving or just informing |

---

## Dimension 3 — Trust Accumulation

What it measures: whether the site is building genuine authority over time.

| Metric | Source | Frequency |
|---|---|---|
| New referring domain count (monthly additions) | Ahrefs / Majestic / Moz or equivalent | Monthly |
| Referring domain diversity (variety of site types) | Same | Quarterly |
| Branded search volume growth | GSC brand filter | Quarterly |
| External citation frequency (mentions without links) | Brand monitoring tool or manual | Quarterly |
| E-E-A-T signal count per Follower page | Internal audit | 6-monthly |

**Trust accumulation thresholds:**

| Threshold | Interpretation |
|---|---|
| 0 new referring domains for 6+ months | Trust is not growing; assess whether the content is citation-worthy |
| Referring domains concentrated in one site type | Weak authority footprint; diversify content topics |
| Branded search volume flat or declining | Brand recall problem; content alone won't fix this |
| E-E-A-T signal count declining on Followers | Trust erosion; schedule Costly Signal audit for affected pages |

---

## Dimension 4 — Adaptive Gain

What it measures: the system's learning rate. How much of the experimental layer is producing validated knowledge.

This is ALCHEMY-HIVE's unique measurement layer. No standard SEO dashboard tracks it.

| Metric | Source | Frequency |
|---|---|---|
| Scout graduation rate (scouts graduating / scouts deployed, per quarter) | memory.md Graduation Log | Quarterly |
| Outlier graduation rate | memory.md Graduation Log | Quarterly |
| Trivia Amplifier win rate | memory.md Trivia Amplifier Log | Quarterly |
| Named failure reasons per retired scout/outlier | memory.md Scout and Outlier Logs | Quarterly |
| Protocol performance by alchemy protocol type | memory.md Alchemy Applications | Quarterly |

**Adaptive Gain benchmarks:**

| Benchmark | Interpretation |
|---|---|
| Scout graduation rate >30% | System is discovering real demand; scouts are well-briefed |
| Scout graduation rate <15% | Scouts are being briefed on noise, not signal; review waggle-dance procedure |
| Outlier graduation rate >25% | Non-logical interventions are producing real results |
| Outlier graduation rate <10% | Protocol selection may be wrong; review alchemy-router heuristics |
| Any single alchemy protocol with 0% graduation across 5+ applications | Protocol may be misapplied; review its entrypoint criteria |
| Trivia win rate >40% | High-leverage trivial interventions are being identified correctly |

---

## Dimension 5 — Anti-Fragility Index

What it measures: whether the site benefits from disruption or breaks under it.

Tracked by monitoring performance through algorithm update periods. Not tracked monthly — only observable when an update occurs.

| Event | Measurement | Interpretation |
|---|---|---|
| Major Google algorithm update | Compare average position for top 10 Followers: 30 days before vs. 30 days after | Maintained or improved without intervention → anti-fragile; Declined requiring emergency intervention → fragile |
| Google AI Overview expansion | Track AI Overview citation rate before and after expansion period | Site cited more often → content quality aligned with AI systems; Site cited less → content being displaced |
| Competitor surge | Note when a competitor suddenly improves across shared queries | If site maintains position: topical authority is solid; If site is displaced: Memory assets may be under-defended |

**Anti-fragility scoring:**

| Score | Criteria |
|---|---|
| +2 | Maintained or improved positions through update without intervention |
| +1 | Minor position drops (<5 positions) that self-corrected within 60 days |
| 0 | No data (no update in period) |
| -1 | Position drops requiring a refresh cycle to recover |
| -2 | Significant drops requiring emergency content overhaul |

Cumulative anti-fragility score tracked in `memory/memory.md §Sites.[domain]`.

---

## Measurement snapshot format

Produce at each quarterly measurement session:

```
MEASUREMENT SNAPSHOT
Site: [domain]
Date: [DATE]
Period: [Q1/Q2/Q3/Q4 YYYY]

DIMENSION 1 — VISIBILITY
  Primary Follower avg position: [number]
  Impressions trend: [+/-X% vs. last period]
  Organic clicks trend: [+/-X% vs. last period]
  AI Overview citations: [count of pages cited]
  Featured snippets: [count]
  Branded search volume: [trend: growing / stable / declining]
  Visibility score: [0–10]

DIMENSION 2 — COGNITIVE FRICTION
  Bounce rate (Follower average): [%]
  Pages exceeding bounce alert threshold: [list URLs or "none"]
  Scroll depth (average for long-form Followers): [%]
  Return visit rate: [%]
  Alerts triggered this period: [list or "none"]

DIMENSION 3 — TRUST ACCUMULATION
  New referring domains this period: [count]
  Total referring domains: [count]
  Branded search volume: [count or trend]
  E-E-A-T audit findings: [summary or "not run this period"]

DIMENSION 4 — ADAPTIVE GAIN
  Scouts deployed this period: [count]
  Scouts graduated this period: [count]
  Scout graduation rate: [%]
  Outliers deployed this period: [count]
  Outliers graduated this period: [count]
  Outlier graduation rate: [%]
  Trivia tests run: [count]
  Trivia wins: [count]
  Win rate: [%]
  Most productive alchemy protocol this period: [protocol name]

DIMENSION 5 — ANTI-FRAGILITY
  Algorithm updates in period: [Y/N — which ones]
  Anti-fragility events: [list update events and score impact]
  Cumulative anti-fragility score: [number]

OVERALL ASSESSMENT: [2–3 sentences on system health and top priority for next period]
```

Write snapshot to `memory/memory.md §Sites.[domain]`.

---

## Link contracts

- `memory/memory.md §Sites.[domain]` — receives measurement snapshots (this file writes to memory)
- `audit/site-audit.md §Phase 6` — supplies baseline data to §Baseline establishment (site-audit calls this file)
- `roles/follower-bee.md` — lateral: follower performance tracked in Dimensions 1 and 2 (follower-bee supplies data; this file tracks it)
- `roles/scout-bee.md` — lateral: scout success tracked in Dimension 4 (scout-bee supplies data; this file tracks it)
- `roles/outlier-bee.md` — lateral: outlier success tracked in Dimensions 1 and 4
- `core/colony-core.md` — lateral: technical compliance feeds Dimension 1 scoring
- `audit/feedback-loops.md` — lateral: Dimension 2 alert thresholds trigger feedback-loops when breached
