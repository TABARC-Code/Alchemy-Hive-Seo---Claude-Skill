---
id: colony-core
version: "1.0"
layer: core

links:
  calls:
    - id: memory
      reason: "writes colony-core audit results per page"
      contract: "memory §Sites.[domain].Audit History receives colony-core checklist output"

  called_by:
    - id: site-audit
      reason: "runs colony-core checklist on every indexed page during audit"
      contract: "§Checklist receives page URL and available crawl data from site-audit"
    - id: scout-bee
      reason: "validates every scout page against C1–C10 before marking as live"
      contract: "§Checklist receives scout page URL from scout-bee §Pre-live validation"
    - id: follower-bee
      reason: "validates follower pages at each refresh cycle"
      contract: "§Checklist receives follower URL from follower-bee §Refresh cycle"
    - id: memory-bee
      reason: "validates memory assets at each 6-month audit"
      contract: "§Checklist receives memory asset URL from memory-bee §Audit procedure"
    - id: outlier-bee
      reason: "validates outlier pages — technical compliance mandatory even for outliers"
      contract: "§Checklist receives outlier URL from outlier-bee §Pre-live validation"

  chain_down:
    - id: memory
      relationship: "audit results written to memory after every checklist run"
  chain_up:
    - id: site-audit
      relationship: "receives page list and crawl data from site-audit"

  lateral:
    - id: measurement-architecture
      relationship: "colony-core technical compliance feeds into Dimension 1 visibility scores"
---

# Colony Core — Determinate Invariants

Ten rules that govern every page in the system regardless of role. Not negotiable. Not subject to experimentation. Scouts, Followers, Memory assets, and Outliers all pass C1–C10 or they are not published.

---

## Entrypoint

Receives a page URL (or list of URLs) from: `site-audit.md`, `scout-bee.md`, `follower-bee.md`, `memory-bee.md`, or `outlier-bee.md`.

Outputs: a per-page checklist result with pass/fail/action-needed per rule, written to `memory/memory.md §Sites.[domain].Audit History`.

---

## The Checklist

Run every item for every page. Record pass, fail, or action-needed. A page with any fail is not live-ready.

---

### C1 — Every page must be technically reachable

**What to check:**

1. Fetch the page via a standard HTTP GET request
2. Confirm status code is 200
3. Confirm at least one crawlable HTML `<a href>` link points to this page from another indexed page on the same domain
4. Confirm the page does not rely on JavaScript rendering to expose its primary content — the HTML source must contain the main body text
5. Confirm no `X-Robots-Tag: noindex` in the response headers

**Pass criteria:** 200 status, HTML-crawlable inbound link exists, content in raw HTML source, no noindex header.

**Fail actions:**
- Non-200: diagnose redirect chain, server error, or DNS issue
- No inbound crawlable link: add one from a relevant indexed page before any other work
- Content in JS only: request static rendering or SSR implementation
- Noindex header present: confirm it is intentional; if not, remove

---

### C2 — Every page must declare canonical intent

**What to check:**

1. Inspect the `<link rel="canonical" href="...">` tag in `<head>`
2. Confirm the canonical points to the URL you intend to rank (usually itself for unique pages, or the preferred variant for near-duplicates)
3. Confirm the canonical is consistent: the URL in the canonical tag must be accessible and return 200
4. For paginated series: confirm canonical handling is deliberate (self-referencing or rel=next/prev — not all pointing to page 1)
5. Check for conflicting canonicals (canonical in `<head>` vs. canonical in sitemap pointing to different URLs)

**Pass criteria:** Canonical present, self-referencing or pointing to correct preferred URL, no conflicts, target URL returns 200.

**Fail actions:**
- Missing canonical: add self-referencing canonical immediately
- Canonical pointing to a non-200 URL: fix the target or change the canonical
- Conflicting canonicals: resolve to a single consistent declaration

---

### C3 — Every indexable page must be allowed to exist

**What to check:**

1. Confirm `robots.txt` does not disallow this URL or its parent directory
2. Confirm `<meta name="robots" content="...">` does not include `noindex`
3. Confirm the page is included in (or not excluded from) the XML sitemap if it is a primary indexed page
4. Confirm any `noindex` that is present is deliberate — cross-reference with page role assignment in memory.md

**Pass criteria:** Not disallowed in robots.txt, no noindex meta tag, included in sitemap (for primary pages).

**Fail actions:**
- Accidental robots.txt block: remove the disallow rule
- Accidental noindex: remove the meta tag
- Missing from sitemap: add to sitemap and resubmit

---

### C4 — Mobile parity is mandatory

**What to check:**

1. Open the page in a mobile viewport (375px wide) — confirm content is accessible without horizontal scrolling
2. Confirm the viewport meta tag is present: `<meta name="viewport" content="width=device-width, initial-scale=1">`
3. Confirm all primary content visible on desktop is also present in the mobile-rendered HTML (no desktop-only content blocks that Google would miss in mobile-first indexing)
4. Confirm interactive elements (buttons, forms, links) are tappable at mobile sizes (minimum 44×44px touch target)
5. Confirm font sizes are legible at mobile without zooming (minimum 16px for body text)

**Pass criteria:** All five checks pass.

**Fail actions:**
- Horizontal overflow: identify the overflowing element and constrain it
- Missing viewport meta: add it
- Desktop-only content: move content to mobile-visible markup
- Tiny tap targets: increase padding or element size
- Illegible font: increase base font size

---

### C5 — Structured data must reflect visible truth

**What to check:**

1. If structured data is present, use Google's Rich Results Test to validate it
2. Confirm every property in the structured data has a corresponding visible element on the page (e.g., `name`, `description`, `datePublished` should all be visible to a human reader)
3. Confirm no properties are marked up that do not appear on the page
4. Confirm the structured data type is appropriate for the page content (Article, FAQPage, HowTo, Product, etc.)

**Pass criteria:** No validation errors, all marked-up properties visibly present, appropriate type used.

**Fail actions:**
- Validation errors: fix per Google's Rich Results Test error messages
- Invisible properties: either make them visible or remove them from markup
- Inappropriate type: change to the correct schema type

*If no structured data is present: this is not a fail. Structured data is not mandatory. The rule only governs structured data that exists.*

---

### C6 — Page experience must support content

**What to check:**

1. Run Core Web Vitals check (via PageSpeed Insights or CrUX data if available)
2. Confirm LCP (Largest Contentful Paint) is under 2.5 seconds on mobile
3. Confirm CLS (Cumulative Layout Shift) is under 0.1
4. Confirm INP (Interaction to Next Paint) is under 200ms
5. Confirm no intrusive interstitials that obscure the main content on mobile (pop-ups that cover the content before the user has read anything)

**Pass criteria:** All three Core Web Vitals in "Good" range, no intrusive interstitials.

**Fail actions:**
- Poor LCP: identify the largest element (usually hero image or heading) and optimise its load path
- High CLS: identify the shifting element (usually images without dimensions, or late-loading ads) and fix
- Poor INP: reduce JavaScript execution time on the critical path
- Intrusive interstitials: delay trigger to after 10 seconds or remove

---

### C7 — Every page must have a named user problem

**What to check:**

1. Read the page without any SEO context. State in one sentence what specific problem this page solves for a real person.
2. Confirm the problem statement is specific — not "provides information about X" but "helps someone who needs to do Y without making mistake Z"
3. Confirm the page's content actually addresses that problem end-to-end

**Pass criteria:** You can state the specific user problem in one sentence, and the page resolves it completely.

**Fail actions:**
- Cannot state a specific problem: the page has no strategic identity — assign it a role review immediately
- Problem stated but page doesn't resolve it: rewrite to close the gap, or narrow the problem to what the page actually does

---

### C8 — Every page must add to the information set

**What to check:**

Run the four-question Counterfactual Content Test from `intelligence/counterfactual-test.md`:

1. Would the information landscape be meaningfully different without this page?
2. Does a competitor's closest page fully substitute for it?
3. Does this page contain at least one element not present in the top-5 SERP results?
4. Would a reader be measurably better equipped to act after reading this?

**Pass criteria:** Yes to Q1 and Q3, No to Q2, Yes to Q4.

**Fail actions:**
- Fails Q1 and Q2: commodity content — redesign to add original synthesis, first-hand experience, unique structure, new data, or a clearer explanation than anything in the SERP
- Fails Q3: research the top-5 SERP results and identify the gap — build content specifically to fill it
- Fails Q4: the page is informational decoration — give it a practical outcome, a decision tool, or a definitive recommendation

---

### C9 — Every page must declare or imply its trustworthiness

**What to check:**

1. Identify which of the following trust signals are present:
   - Named author with verifiable off-site presence (linked profile, publication history)
   - Date of publication and last update visible
   - Cited sources linking to primary references (not just other blog posts)
   - First-hand experience indicators (specific product/service details, test results, named examples)
   - Methodology or process described
   - Institutional affiliation or credentials where relevant

2. Count trust signals present. For Follower pages: minimum two. For Memory assets: minimum two (add during refresh). For Scout pages: minimum one. For Outlier pages: minimum one.

**Pass criteria:** Meets minimum trust signal count for the page's role.

**Fail actions:**
- No trust signals: add at minimum a named author and a dated publication/update notice
- Unverifiable authorship: link the author name to an external profile with enough history to be credible

---

### C10 — Internal links must be purposeful

**What to check:**

1. For every internal link on this page, confirm it does one of: define, deepen, compare, route, convert, or troubleshoot
2. Confirm no internal links use generic anchor text ("click here", "read more", "this article") where descriptive text is possible
3. Confirm the pages being linked to are in a role that justifies receiving authority from this page
4. Confirm there are no broken internal links (404s on link destinations)

**Pass criteria:** Every internal link has a purpose and descriptive anchor text; no broken links.

**Fail actions:**
- Generic anchor text: rewrite with destination-describing text
- Link to a 404: fix the destination or remove the link
- Purposeless link: remove it or replace with a link to a page that serves the narrative

---

## Checklist output format

For each page checked, produce:

```
Page: [URL]
Role: [Scout / Follower / Memory / Outlier / Unassigned]

C1 Reachability:      [PASS / FAIL: reason]
C2 Canonical:         [PASS / FAIL: reason]
C3 Indexability:      [PASS / FAIL: reason]
C4 Mobile parity:     [PASS / FAIL: reason]
C5 Structured data:   [PASS / N/A / FAIL: reason]
C6 Page experience:   [PASS / FAIL: reason]
C7 User problem:      [PASS / FAIL: stated problem or "unstated"]
C8 Information gain:  [PASS / FAIL: CCT result]
C9 Trust signals:     [PASS / FAIL: count and types found]
C10 Internal links:   [PASS / FAIL: reason]

Overall: [PASS / ACTION NEEDED]
Actions required: [list]
```

Write this output to `memory/memory.md §Sites.[domain].Audit History` with the date of the check.

---

## Link contracts

- `memory/memory.md §Sites.[domain].Audit History` — receives checklist output after every run (called by this file)
- `site-audit.md §Colony Core Checklist` — supplies page URL list to this file (calls this file)
- `scout-bee.md §Pre-live validation` — supplies scout page URL to this file before marking live
- `follower-bee.md §Refresh cycle` — supplies follower URL at each refresh
- `memory-bee.md §Audit procedure` — supplies memory asset URL at each 6-month audit
- `outlier-bee.md §Pre-live validation` — supplies outlier URL before marking live
- `intelligence/counterfactual-test.md` — C8 delegates full test to this file
- `measurement-architecture.md §Dimension 1 Visibility` — receives technical compliance summary for scoring
